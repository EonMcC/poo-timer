(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["timer-environment-environment-setup-environment-setup-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/timer-environment/environment-setup/environment-setup.page.html":
    /*!***********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/timer-environment/environment-setup/environment-setup.page.html ***!
      \***********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppTimerEnvironmentEnvironmentSetupEnvironmentSetupPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n  <h1>Environment Setup</h1>\n  <p id=\"sub-heading\">Add a new environment</p>\n\n  <form #environmentSetupForm=\"ngForm\" (ngSubmit)=\"onSubmit(environmentSetupForm)\">\n    <!-- name -->\n    <ion-item>\n      <ion-label\n        class=\"label\" \n        position=\"stacked\"\n        text-wrap\n      >What would you like to time?</ion-label>\n      <ion-input\n        type=\"text\"\n        placeholder=\"Run, Sleep etc.\"\n        name=\"name\"\n        [(ngModel)]=\"name\"\n        value=\"string\"\n        required\n      >\n      </ion-input>\n    </ion-item>\n\n    <!-- same? -->\n    <ion-item>\n      <ion-label\n        class=\"label\"\n        position=\"stacked\"\n        text-wrap\n      >Use the same wage and currency as Poo Timer?</ion-label>\n      <ion-select\n        type=\"search\"\n        placeholder=\"Select\"\n        name=\"same\"\n        [(ngModel)]=\"same\"\n        value=\"boolean\"\n        interface=\"popover\"\n        required\n      >\n        <ion-select-option [value]=\"true\">Yes</ion-select-option>\n        <ion-select-option [value]=\"false\">No</ion-select-option>\n\n      </ion-select>\n    </ion-item>\n\n        <!-- hourlyRate -->\n        <ion-item *ngIf=\"!same\">\n          <ion-label\n            class=\"label\" \n            position=\"stacked\"\n            text-wrap\n          >What is your time worth for this task?</ion-label>\n          <ion-input\n            type=\"text\"\n            placeholder=\"Enter hourly rate\"\n            name=\"hourlyRate\"\n            [(ngModel)]=\"hourlyRate\"\n            value=\"number\"\n            [required]=\"!same\"\n          >\n          </ion-input>\n        </ion-item>\n\n    <!-- currency -->\n    <ion-item *ngIf=\"!same\">\n      <ion-label\n        class=\"label\"\n        position=\"stacked\"\n        text-wrap\n      >And what currency is that in?</ion-label>\n      <ion-select\n        type=\"search\"\n        placeholder=\"Choose currency\"\n        name=\"currency\"\n        [(ngModel)]=\"currency\"\n        value=\"string\"\n        interface=\"popover\"\n        [required]=\"!same\"\n      >\n        <ion-select-option value=\"£ Pieces of Unicorn Dust\">Unicorn Dust</ion-select-option>\n        <ion-select-option value=\"$ Pieces of Eight\">Pieces of Eight</ion-select-option>\n        <ion-select-option value=\"£ Old Money Pounds\">Old Money</ion-select-option>\n        <ion-select-option value=\"£\">£ Pounds</ion-select-option>\n        <ion-select-option value=\"$\">$ Dollars</ion-select-option>\n        <ion-select-option value=\"€\">€ Euros</ion-select-option>\n\n      </ion-select>\n    </ion-item>\n\n\n      <div id=\"btn-wrapper\">\n        <ion-button\n          type=\"submit\"\n          color=\"primary\"\n          id=\"primary-btn\"\n        >Next</ion-button>\n      </div>\n  </form>\n  \n</ion-content>\n\n\n\n\n";
      /***/
    },

    /***/
    "./src/app/timer-environment/environment-setup/environment-setup-routing.module.ts":
    /*!*****************************************************************************************!*\
      !*** ./src/app/timer-environment/environment-setup/environment-setup-routing.module.ts ***!
      \*****************************************************************************************/

    /*! exports provided: EnvironmentSetupPageRoutingModule */

    /***/
    function srcAppTimerEnvironmentEnvironmentSetupEnvironmentSetupRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EnvironmentSetupPageRoutingModule", function () {
        return EnvironmentSetupPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _environment_setup_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./environment-setup.page */
      "./src/app/timer-environment/environment-setup/environment-setup.page.ts");

      var routes = [{
        path: '',
        component: _environment_setup_page__WEBPACK_IMPORTED_MODULE_3__["EnvironmentSetupPage"]
      }];

      var EnvironmentSetupPageRoutingModule = function EnvironmentSetupPageRoutingModule() {
        _classCallCheck(this, EnvironmentSetupPageRoutingModule);
      };

      EnvironmentSetupPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], EnvironmentSetupPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/timer-environment/environment-setup/environment-setup.module.ts":
    /*!*********************************************************************************!*\
      !*** ./src/app/timer-environment/environment-setup/environment-setup.module.ts ***!
      \*********************************************************************************/

    /*! exports provided: EnvironmentSetupPageModule */

    /***/
    function srcAppTimerEnvironmentEnvironmentSetupEnvironmentSetupModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EnvironmentSetupPageModule", function () {
        return EnvironmentSetupPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _environment_setup_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./environment-setup-routing.module */
      "./src/app/timer-environment/environment-setup/environment-setup-routing.module.ts");
      /* harmony import */


      var _environment_setup_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./environment-setup.page */
      "./src/app/timer-environment/environment-setup/environment-setup.page.ts");

      var EnvironmentSetupPageModule = function EnvironmentSetupPageModule() {
        _classCallCheck(this, EnvironmentSetupPageModule);
      };

      EnvironmentSetupPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _environment_setup_routing_module__WEBPACK_IMPORTED_MODULE_5__["EnvironmentSetupPageRoutingModule"]],
        declarations: [_environment_setup_page__WEBPACK_IMPORTED_MODULE_6__["EnvironmentSetupPage"]]
      })], EnvironmentSetupPageModule);
      /***/
    },

    /***/
    "./src/app/timer-environment/environment-setup/environment-setup.page.scss":
    /*!*********************************************************************************!*\
      !*** ./src/app/timer-environment/environment-setup/environment-setup.page.scss ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppTimerEnvironmentEnvironmentSetupEnvironmentSetupPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "h1 {\n  font-size: 48px;\n  color: var(--ion-color-secondary);\n  margin: 32px auto 0px auto;\n  text-align: center;\n  line-height: 45px;\n}\n\n#sub-heading {\n  font-size: 18px;\n  color: var(--ion-color-dark);\n  margin: 0px auto 16px auto;\n  text-align: center;\n}\n\nion-item {\n  --background: var(--ion-color-primary-tint);\n  --border-color: var(--ion-color-secondary);\n  margin-bottom: 0px;\n  font-size: 34px;\n}\n\n.label {\n  font-size: 24px;\n  color: var(--ion-color-secondary);\n  margin-bottom: 8px;\n}\n\n#btn-wrapper {\n  margin: 32px auto;\n  width: 100%;\n  background: var(--ion-color-background);\n  z-index: 15;\n}\n\n#primary-btn {\n  display: block;\n  width: 90vw;\n  margin: 0 auto;\n  bottom: 32px;\n  z-index: 100;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGltZXItZW52aXJvbm1lbnQvZW52aXJvbm1lbnQtc2V0dXAvZW52aXJvbm1lbnQtc2V0dXAucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLGlDQUFBO0VBQ0EsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSwwQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSwyQ0FBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsaUNBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsdUNBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQUNGIiwiZmlsZSI6InNyYy9hcHAvdGltZXItZW52aXJvbm1lbnQvZW52aXJvbm1lbnQtc2V0dXAvZW52aXJvbm1lbnQtc2V0dXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaDF7XHJcbiAgZm9udC1zaXplOiA0OHB4O1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcclxuICBtYXJnaW46IDMycHggYXV0byAwcHggYXV0bztcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgbGluZS1oZWlnaHQ6IDQ1cHg7XHJcbn1cclxuXHJcbiNzdWItaGVhZGluZyB7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgbWFyZ2luOiAwcHggYXV0byAxNnB4IGF1dG87XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10aW50KTtcclxuICAtLWJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIGZvbnQtc2l6ZTogMzRweDtcclxufVxyXG5cclxuLmxhYmVsIHtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gIG1hcmdpbi1ib3R0b206IDhweDtcclxufVxyXG5cclxuI2J0bi13cmFwcGVyIHtcclxuICBtYXJnaW46IDMycHggYXV0bztcclxuICB3aWR0aDogMTAwJTtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmFja2dyb3VuZCk7XHJcbiAgei1pbmRleDoxNTtcclxufVxyXG5cclxuI3ByaW1hcnktYnRuIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICB3aWR0aDogOTB2dztcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBib3R0b206IDMycHg7XHJcbiAgei1pbmRleDogMTAwO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/timer-environment/environment-setup/environment-setup.page.ts":
    /*!*******************************************************************************!*\
      !*** ./src/app/timer-environment/environment-setup/environment-setup.page.ts ***!
      \*******************************************************************************/

    /*! exports provided: EnvironmentSetupPage */

    /***/
    function srcAppTimerEnvironmentEnvironmentSetupEnvironmentSetupPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EnvironmentSetupPage", function () {
        return EnvironmentSetupPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/services/environment-storage.service */
      "./src/app/services/environment-storage.service.ts");
      /* harmony import */


      var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/toast.service */
      "./src/app/services/toast.service.ts");

      var EnvironmentSetupPage = /*#__PURE__*/function () {
        function EnvironmentSetupPage(environmentStorageService, router, toastService) {
          _classCallCheck(this, EnvironmentSetupPage);

          this.environmentStorageService = environmentStorageService;
          this.router = router;
          this.toastService = toastService;
          this.formValid = false;
          this.same = true;
        }

        _createClass(EnvironmentSetupPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.environmentStorageService.listEnvironments().then(function (environments) {
              _this.environments = environments;
            });
          }
        }, {
          key: "onSubmit",
          value: function onSubmit(form) {
            var _this2 = this;

            if (form.valid) {
              var id = this.environments.length + 1;
              var name = form.value.name;
              var hourlyRate;
              var currency;

              if (form.value.same) {
                hourlyRate = this.environments[0].hourlyRate;
                currency = this.environments[0].currency;
              } else {
                hourlyRate = form.value.hourlyRate;
                currency = form.value.currency;
              }

              this.environmentStorageService.addEnvironment({
                id: id,
                name: name,
                firstTimeDate: null,
                hourlyRate: hourlyRate,
                currency: currency,
                longestTime: 0,
                shortestTime: 0,
                totalTime: 0,
                itemCount: 0,
                totalPaid: 0,
                lastItemID: 0,
                lastTimeDate: null,
                streak: 0
              }).then(function () {
                _this2.router.navigate(['/environment-select']);

                _this2.formValid = true;
              });
              form.reset();
            } else {
              this.toastService.presentToast('Please fill in all information');
            }
          }
        }]);

        return EnvironmentSetupPage;
      }();

      EnvironmentSetupPage.ctorParameters = function () {
        return [{
          type: src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_3__["EnvironmentStorageService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"]
        }];
      };

      EnvironmentSetupPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-environment-setup',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./environment-setup.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/timer-environment/environment-setup/environment-setup.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./environment-setup.page.scss */
        "./src/app/timer-environment/environment-setup/environment-setup.page.scss"))["default"]]
      })], EnvironmentSetupPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=timer-environment-environment-setup-environment-setup-module-es5.js.map