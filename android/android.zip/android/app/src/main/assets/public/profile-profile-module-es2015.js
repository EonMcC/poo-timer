(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/profile/profile.page.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/profile/profile.page.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n\n  <div id=\"avatar\"></div>\n  <h1 *ngIf=\"user\">{{user.userName}}</h1>\n\n  <p *ngIf=\"user && firstTimeDate\">{{user.userName}} has been {{environment.name}} Timing since <span>{{firstTimeDate}}</span>.</p>\n  <p\n    *ngIf=\"user && environment.hourlyRate\">\n    Currently rocking an hourly rate of \n    <span>\n      {{environment.currency.slice(0,1) + environment.hourlyRate}}</span>, {{user.userName}} has been paid a grand total of \n    <span>\n      {{grandTotal}}\n    </span> to poo at work.\n  </p>\n  <p *ngIf=\"user && !firstTimeDate\">What are you waiting for? Start {{environment.name}} Timing today!</p>\n  <p *ngIf=\"user && firstTimeDate\">That's some great work {{user.userName}}, we salute you</p>\n\n</ion-content>\n\n<div id=\"btn-wrapper\">\n  <ion-button color=\"secondary\" id=\"secondary-btn\" (click)=\"goBack()\">BACK</ion-button>\n</div>\n");

/***/ }),

/***/ "./src/app/home/profile/profile-routing.module.ts":
/*!********************************************************!*\
  !*** ./src/app/home/profile/profile-routing.module.ts ***!
  \********************************************************/
/*! exports provided: ProfilePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function() { return ProfilePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profile.page */ "./src/app/home/profile/profile.page.ts");




const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"]
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProfilePageRoutingModule);



/***/ }),

/***/ "./src/app/home/profile/profile.module.ts":
/*!************************************************!*\
  !*** ./src/app/home/profile/profile.module.ts ***!
  \************************************************/
/*! exports provided: ProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function() { return ProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./profile-routing.module */ "./src/app/home/profile/profile-routing.module.ts");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profile.page */ "./src/app/home/profile/profile.page.ts");







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfilePageRoutingModule"]
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
    })
], ProfilePageModule);



/***/ }),

/***/ "./src/app/home/profile/profile.page.scss":
/*!************************************************!*\
  !*** ./src/app/home/profile/profile.page.scss ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("h1 {\n  margin: 40px auto 40px auto;\n  text-align: center;\n  font-size: 74px;\n}\n\np {\n  color: var(--ion-color-secondary);\n  font-size: 24px;\n  margin: 0px 24px 24px 24px;\n}\n\np span {\n  color: var(--ion-color-dark);\n}\n\n#btn-wrapper {\n  margin-bottom: 16px;\n  width: 100%;\n  background: var(--ion-color-background);\n}\n\n#secondary-btn {\n  display: block;\n  width: 90vw !important;\n  margin: 0 auto;\n  bottom: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQVFBO0VBQ0UsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFQRjs7QUFVQTtFQUNFLGlDQUFBO0VBQ0EsZUFBQTtFQUNBLDBCQUFBO0FBUEY7O0FBU0U7RUFDRSw0QkFBQTtBQVBKOztBQVdBO0VBQ0UsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsdUNBQUE7QUFSRjs7QUFXQTtFQUNFLGNBQUE7RUFDQSxzQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FBUkYiLCJmaWxlIjoic3JjL2FwcC9ob21lL3Byb2ZpbGUvcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyAjYXZhdGFyIHtcclxuLy8gICB3aWR0aDogMTY0cHg7XHJcbi8vICAgaGVpZ2h0OiAxNjRweDtcclxuLy8gICBtYXJnaW46IDI0cHggYXV0byAxNnB4IGF1dG87XHJcbi8vICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4vLyAgIGJhY2tncm91bmQ6IHVybCguLi8uLi8uLi9hc3NldHMvaW1hZ2VzL3Byb2ZpbGUtYXZhdGFyLnBuZyk7XHJcbi8vIH1cclxuXHJcbmgxIHtcclxuICBtYXJnaW46IDQwcHggYXV0byA0MHB4IGF1dG87XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogNzRweDtcclxufVxyXG5cclxucCB7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gIGZvbnQtc2l6ZTogMjRweDtcclxuICBtYXJnaW46IDBweCAyNHB4IDI0cHggMjRweDtcclxuXHJcbiAgJiBzcGFuIHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgfVxyXG59XHJcblxyXG4jYnRuLXdyYXBwZXIge1xyXG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWJhY2tncm91bmQpO1xyXG59XHJcblxyXG4jc2Vjb25kYXJ5LWJ0biB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgd2lkdGg6IDkwdncgIWltcG9ydGFudDtcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBib3R0b206IDMycHg7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/home/profile/profile.page.ts":
/*!**********************************************!*\
  !*** ./src/app/home/profile/profile.page.ts ***!
  \**********************************************/
/*! exports provided: ProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePage", function() { return ProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_app_services_data_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/data-service.service */ "./src/app/services/data-service.service.ts");
/* harmony import */ var src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/environment-storage.service */ "./src/app/services/environment-storage.service.ts");
/* harmony import */ var src_app_services_user_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/user-storage.service */ "./src/app/services/user-storage.service.ts");







let ProfilePage = class ProfilePage {
    constructor(router, userStorageService, environmentStorageService, dataService) {
        this.router = router;
        this.userStorageService = userStorageService;
        this.environmentStorageService = environmentStorageService;
        this.dataService = dataService;
    }
    ngOnInit() {
        this.user = this.dataService.user;
        this.environment = this.dataService.environment;
        this.calculateGrandTotal();
        this.calculateSignupDate();
    }
    goBack() {
        this.router.navigate(['/home']);
    }
    calculateSignupDate() {
        if (this.environment.firstTimeDate !== null) {
            this.firstTimeDate = moment__WEBPACK_IMPORTED_MODULE_3__(this.environment.firstTimeDate).format('MMM \'YY');
        }
        console.log(this.firstTimeDate);
    }
    calculateGrandTotal() {
        const paid = this.environment.totalPaid;
        if (paid) {
            if (paid < .01) {
                const paidNumber = paid.toFixed(3);
                this.formatMoney(paidNumber);
            }
            else {
                const paidNumber = paid.toFixed(2);
                this.formatMoney(paidNumber);
            }
        }
        else {
            this.grandTotal = 'nothing';
        }
    }
    formatMoney(paid) {
        const currency = this.environment.currency;
        if (currency === '£ Pieces of Unicorn Dust' || currency === '$ Pieces of Eight' || currency === '£ Old Money Pounds') {
            const symbol = currency.slice(0, 1);
            const moneyType = currency.slice(2);
            this.grandTotal = `${symbol}${paid} ${moneyType}`;
        }
        else {
            this.grandTotal = `${currency}${paid}`;
        }
    }
};
ProfilePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: src_app_services_user_storage_service__WEBPACK_IMPORTED_MODULE_6__["UserStorageService"] },
    { type: src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_5__["EnvironmentStorageService"] },
    { type: src_app_services_data_service_service__WEBPACK_IMPORTED_MODULE_4__["DataServiceService"] }
];
ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-profile',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./profile.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/profile/profile.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./profile.page.scss */ "./src/app/home/profile/profile.page.scss")).default]
    })
], ProfilePage);



/***/ })

}]);
//# sourceMappingURL=profile-profile-module-es2015.js.map