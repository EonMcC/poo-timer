(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-settings-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/settings/settings.page.html":
    /*!****************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/settings/settings.page.html ***!
      \****************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomeSettingsSettingsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n  <div id=\"cog-cont\"><ion-icon id=\"cog\" name=\"cog\"></ion-icon></div>\n  <h1>Settings</h1>\n  <h2>Change the things</h2>\n\n  <ion-list id=\"menu-list\" lines=\"none\">\n\n    <ion-item class=\"menu-item\">\n      <ion-label\n        class=\"label\"\n        position=\"stacked\"\n      >Currency</ion-label>\n      <ion-select\n        type=\"search\"\n        name=\"currency\"\n        [(ngModel)]=\"environment.currency\"\n        value=\"string\"\n        interface=\"popover\"\n        (ionChange)=\"handleUpdateEnvironment()\"\n      >\n        <ion-select-option value=\"£ Pieces of Unicorn Dust\">£ Unicorn Dust</ion-select-option>\n        <ion-select-option value=\"$ Pieces of Eight\">$ Pieces of Eight</ion-select-option>\n        <ion-select-option value=\"£ Old Money Pounds\">£ Old Money</ion-select-option>\n        <ion-select-option value=\"£\">£ Pounds</ion-select-option>\n        <ion-select-option value=\"$\">$ Dollars</ion-select-option>\n        <ion-select-option value=\"€\">€ Euros</ion-select-option>\n\n      </ion-select>\n    </ion-item>\n\n    <ion-item class=\"menu-item\">\n      <ion-label\n        class=\"label\"\n        position=\"stacked\"\n      >Hourly Rate</ion-label>\n      <ion-input\n        type=\"number\"\n        name=\"wage\"\n        [(ngModel)]=\"environment.hourlyRate\"\n        value=\"string\"\n        inputmode=\"decimal\"\n        enterkeyhit=\"done\"\n        (ionBlur)=\"handleUpdateEnvironment()\"\n      >\n      </ion-input>\n    </ion-item>\n\n    <ion-item class=\"menu-item\" (click)=\"handleDeleteStatsClick()\">\n      Clear Stats\n      <ion-icon class=\"menu-icon\" name=\"trash-outline\" slot=\"end\" size=\"large\"></ion-icon>\n    </ion-item>\n    \n    <ion-item *ngIf=\"environment.id !== 1\" class=\"menu-item\" (click)=\"handleDeleteClick()\">\n      Delete Environment\n      <ion-icon class=\"menu-icon\" name=\"trash-outline\" slot=\"end\" size=\"large\"></ion-icon>\n    </ion-item>\n\n\n  </ion-list>\n</ion-content>\n\n<div id=\"btn-wrapper\">\n  <ion-button color=\"secondary\" id=\"secondary-btn\" (click)=\"goBack()\">BACK</ion-button>\n</div>\n";
      /***/
    },

    /***/
    "./src/app/home/settings/settings-routing.module.ts":
    /*!**********************************************************!*\
      !*** ./src/app/home/settings/settings-routing.module.ts ***!
      \**********************************************************/

    /*! exports provided: SettingsPageRoutingModule */

    /***/
    function srcAppHomeSettingsSettingsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SettingsPageRoutingModule", function () {
        return SettingsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _settings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./settings.page */
      "./src/app/home/settings/settings.page.ts");

      var routes = [{
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_3__["SettingsPage"]
      }];

      var SettingsPageRoutingModule = function SettingsPageRoutingModule() {
        _classCallCheck(this, SettingsPageRoutingModule);
      };

      SettingsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], SettingsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/home/settings/settings.module.ts":
    /*!**************************************************!*\
      !*** ./src/app/home/settings/settings.module.ts ***!
      \**************************************************/

    /*! exports provided: SettingsPageModule */

    /***/
    function srcAppHomeSettingsSettingsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SettingsPageModule", function () {
        return SettingsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./settings-routing.module */
      "./src/app/home/settings/settings-routing.module.ts");
      /* harmony import */


      var _settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./settings.page */
      "./src/app/home/settings/settings.page.ts");

      var SettingsPageModule = function SettingsPageModule() {
        _classCallCheck(this, SettingsPageModule);
      };

      SettingsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__["SettingsPageRoutingModule"]],
        declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]]
      })], SettingsPageModule);
      /***/
    },

    /***/
    "./src/app/home/settings/settings.page.scss":
    /*!**************************************************!*\
      !*** ./src/app/home/settings/settings.page.scss ***!
      \**************************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomeSettingsSettingsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "#cog-cont {\n  margin: 32px auto 0px auto;\n  width: 80px;\n}\n\n#cog {\n  color: var(--ion-color-dark);\n  font-size: 80px;\n}\n\nh1 {\n  margin: 0px auto;\n  text-align: center;\n  font-size: 48px;\n  color: var(--ion-color-dark);\n}\n\nh2 {\n  margin: 0px auto 16px auto;\n  text-align: center;\n  font-size: 18px;\n  color: var(--ion-color-secondary);\n}\n\n#main-menu {\n  --background: var(--ion-color-background);\n  pointer-events: auto;\n}\n\n#menu-list {\n  background: var(--ion-color-background);\n  width: 100%;\n}\n\n#menu-list-bottom {\n  position: absolute;\n  width: 100%;\n  bottom: 32px;\n}\n\n.label {\n  font-size: 22px;\n}\n\n.label-stacked.sc-ion-label-ios-h {\n  margin-bottom: -8px;\n}\n\n.menu-item {\n  --background: var(--ion-color-background);\n  font-size: 34px;\n  color: var(--ion-color-dark);\n  border: none;\n  margin-bottom: 24px;\n}\n\n.chevron {\n  margin-right: 0px;\n}\n\n#btn-wrapper {\n  margin-bottom: 16px;\n  width: 100%;\n  background: var(--ion-color-background);\n}\n\n#secondary-btn {\n  display: block;\n  width: 90vw;\n  margin: 0 auto;\n  bottom: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9zZXR0aW5ncy9zZXR0aW5ncy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwwQkFBQTtFQUNBLFdBQUE7QUFDRjs7QUFFQTtFQUNFLDRCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSw0QkFBQTtBQUNGOztBQUVBO0VBQ0UsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxpQ0FBQTtBQUNGOztBQUVBO0VBQ0UseUNBQUE7RUFDQSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsdUNBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UseUNBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSx1Q0FBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQUNGIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9zZXR0aW5ncy9zZXR0aW5ncy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29nLWNvbnQge1xyXG4gIG1hcmdpbjogMzJweCBhdXRvIDBweCBhdXRvO1xyXG4gIHdpZHRoOiA4MHB4O1xyXG59XHJcblxyXG4jY29nIHtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gIGZvbnQtc2l6ZTogODBweDtcclxufVxyXG5cclxuaDEge1xyXG4gIG1hcmdpbjogMHB4IGF1dG87XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogNDhweDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG59XHJcblxyXG5oMiB7XHJcbiAgbWFyZ2luOiAwcHggYXV0byAxNnB4IGF1dG87XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbn1cclxuXHJcbiNtYWluLW1lbnUge1xyXG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWJhY2tncm91bmQpO1xyXG4gIHBvaW50ZXItZXZlbnRzOiBhdXRvO1xyXG59XHJcblxyXG4jbWVudS1saXN0IHtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmFja2dyb3VuZCk7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbiNtZW51LWxpc3QtYm90dG9tIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm90dG9tOiAzMnB4O1xyXG59XHJcblxyXG4ubGFiZWwge1xyXG4gIGZvbnQtc2l6ZTogMjJweDtcclxufVxyXG5cclxuLmxhYmVsLXN0YWNrZWQuc2MtaW9uLWxhYmVsLWlvcy1oIHtcclxuICBtYXJnaW4tYm90dG9tOiAtOHB4O1xyXG59XHJcblxyXG4ubWVudS1pdGVtIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1iYWNrZ3JvdW5kKTtcclxuICBmb250LXNpemU6IDM0cHg7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjRweDtcclxufVxyXG5cclxuLmNoZXZyb24ge1xyXG4gIG1hcmdpbi1yaWdodDogMHB4O1xyXG59XHJcblxyXG4jYnRuLXdyYXBwZXIge1xyXG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWJhY2tncm91bmQpO1xyXG59XHJcblxyXG4jc2Vjb25kYXJ5LWJ0biB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgd2lkdGg6IDkwdnc7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgYm90dG9tOiAzMnB4O1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/home/settings/settings.page.ts":
    /*!************************************************!*\
      !*** ./src/app/home/settings/settings.page.ts ***!
      \************************************************/

    /*! exports provided: SettingsPage */

    /***/
    function srcAppHomeSettingsSettingsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SettingsPage", function () {
        return SettingsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _services_data_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../services/data-service.service */
      "./src/app/services/data-service.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/services/environment-storage.service */
      "./src/app/services/environment-storage.service.ts");
      /* harmony import */


      var src_app_services_user_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/services/user-storage.service */
      "./src/app/services/user-storage.service.ts");
      /* harmony import */


      var src_app_services_item_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/services/item-storage.service */
      "./src/app/services/item-storage.service.ts");
      /* harmony import */


      var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! src/app/services/toast.service */
      "./src/app/services/toast.service.ts");

      var SettingsPage = /*#__PURE__*/function () {
        function SettingsPage(router, dataService, alertController, environmentStorageService, userStorageService, itemStorageService, ngZone, toastService) {
          _classCallCheck(this, SettingsPage);

          this.router = router;
          this.dataService = dataService;
          this.alertController = alertController;
          this.environmentStorageService = environmentStorageService;
          this.userStorageService = userStorageService;
          this.itemStorageService = itemStorageService;
          this.ngZone = ngZone;
          this.toastService = toastService;
        }

        _createClass(SettingsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.environment = this.dataService.environment;
          }
        }, {
          key: "handleUpdateEnvironment",
          value: function handleUpdateEnvironment() {
            var _this = this;

            this.environmentStorageService.updateEnvironment(this.environment).then(function (data) {
              try {
                _this.toastService.presentToast('Setting Updated');
              } catch (error) {
                _this.toastService.presentToast('Update Failed, please try again later');
              }
            });
          }
        }, {
          key: "handleDeleteStatsClick",
          value: function handleDeleteStatsClick() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this2 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.alertController.create({
                        header: 'Confirm!',
                        message: 'This action will delete all stats. Are you sure you want to do this? This action cannot be reversed.',
                        cssClass: "alert-class",
                        buttons: [{
                          text: 'Cancel',
                          role: 'cancel',
                          cssClass: "alert-cancel-button",
                          handler: function handler(data) {
                            console.log('Cancel');
                          }
                        }, {
                          text: 'Delete',
                          cssClass: "alert-confirm-button",
                          handler: function handler() {
                            console.log('Confirm Okay');

                            _this2.deleteStats();
                          }
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      alert.present();

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "deleteStats",
          value: function deleteStats() {
            var _this3 = this;

            this.environment.totalTime = 0;
            this.environment.itemCount = 0;
            this.environment.streak = 0;
            this.environment.shortestTime = null;
            this.environment.longestTime = 0;
            this.environment.totalPaid = 0;
            this.environmentStorageService.updateEnvironment(this.environment).then(function (data) {
              var toastMessage = 'Stats deleted.';

              _this3.toastService.presentToast(toastMessage);
            });
          }
        }, {
          key: "handleDeleteClick",
          value: function handleDeleteClick() {
            this.presentDeleteAlert();
          }
        }, {
          key: "presentDeleteAlert",
          value: function presentDeleteAlert() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this4 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.alertController.create({
                        header: 'Confirm',
                        message: 'Are you sure you want to delete this environment? You will lose all saved data. This action cannot be reversed.',
                        buttons: [{
                          text: 'No',
                          role: 'cancel',
                          handler: function handler(data) {
                            console.log('Cancel');
                          }
                        }, {
                          text: 'Yes',
                          handler: function handler() {
                            console.log('Confirm Okay');

                            _this4.deleteEnvironment();
                          }
                        }]
                      });

                    case 2:
                      alert = _context2.sent;
                      alert.present();

                    case 4:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "deleteEnvironment",
          value: function deleteEnvironment() {
            var _this5 = this;

            this.environmentStorageService.deleteEnvironment(this.environment.id).then(function (data) {
              try {
                _this5.dataService.environment = null;

                _this5.itemStorageService.deleteEnvironmentItems(_this5.dataService.user.activeEnvironmentID);

                _this5.dataService.user.activeEnvironmentID = 1;

                _this5.userStorageService.updateUser(_this5.dataService.user);

                _this5.toastService.presentToast('Environment deleted. Bye Bye');

                _this5.environmentStorageService.listEnvironments().then(function (data) {
                  _this5.router.navigate(['/environment-select']);
                });
              } catch (error) {
                _this5.toastService.presentToast('Deletion Failed, please try again later');
              }
            });
          }
        }, {
          key: "goBack",
          value: function goBack() {
            this.router.navigate(['/home']);
          }
        }]);

        return SettingsPage;
      }();

      SettingsPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _services_data_service_service__WEBPACK_IMPORTED_MODULE_3__["DataServiceService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }, {
          type: src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_5__["EnvironmentStorageService"]
        }, {
          type: src_app_services_user_storage_service__WEBPACK_IMPORTED_MODULE_6__["UserStorageService"]
        }, {
          type: src_app_services_item_storage_service__WEBPACK_IMPORTED_MODULE_7__["ItemStorageService"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"]
        }, {
          type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_8__["ToastService"]
        }];
      };

      SettingsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-settings',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./settings.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/settings/settings.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./settings.page.scss */
        "./src/app/home/settings/settings.page.scss"))["default"]]
      })], SettingsPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=settings-settings-module-es5.js.map