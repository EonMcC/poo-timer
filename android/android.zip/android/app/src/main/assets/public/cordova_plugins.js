
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-nativestorage.mainHandle",
          "file": "plugins/cordova-plugin-nativestorage/www/mainHandle.js",
          "pluginId": "cordova-plugin-nativestorage",
        "clobbers": [
          "NativeStorage"
        ]
        },
      {
          "id": "cordova-plugin-admob-free.AdMob",
          "file": "plugins/cordova-plugin-admob-free/www/admob.js",
          "pluginId": "cordova-plugin-admob-free",
        "clobbers": [
          "admob",
          "AdMob",
          "plugins.AdMob"
        ]
        },
      {
          "id": "cordova-sqlite-storage.SQLitePlugin",
          "file": "plugins/cordova-sqlite-storage/www/SQLitePlugin.js",
          "pluginId": "cordova-sqlite-storage",
        "clobbers": [
          "SQLitePlugin"
        ]
        },
      {
          "id": "cordova-plugin-nativestorage.LocalStorageHandle",
          "file": "plugins/cordova-plugin-nativestorage/www/LocalStorageHandle.js",
          "pluginId": "cordova-plugin-nativestorage"
        },
      {
          "id": "cordova-plugin-nativestorage.NativeStorageError",
          "file": "plugins/cordova-plugin-nativestorage/www/NativeStorageError.js",
          "pluginId": "cordova-plugin-nativestorage"
        },
      {
          "id": "cordova-promise-polyfill.Promise",
          "file": "plugins/cordova-promise-polyfill/www/Promise.js",
          "pluginId": "cordova-promise-polyfill",
        "runs": true
        },
      {
          "id": "cordova-promise-polyfill.promise.min",
          "file": "plugins/cordova-promise-polyfill/www/promise.min.js",
          "pluginId": "cordova-promise-polyfill"
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-admob-sdk": "0.24.1",
      "cordova-plugin-admob-free": "0.27.0",
      "cordova-plugin-nativestorage": "2.3.2",
      "cordova-promise-polyfill": "0.0.2",
      "cordova-sqlite-storage": "5.1.0"
    };
    // BOTTOM OF METADATA
    });
    