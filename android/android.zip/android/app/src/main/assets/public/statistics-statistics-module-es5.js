(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["statistics-statistics-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/statistics/statistics.page.html":
    /*!********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/statistics/statistics.page.html ***!
      \********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomeStatisticsStatisticsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n  <div id=\"bar-chart-cont\"><ion-icon id=\"chart\" name=\"bar-chart\"></ion-icon></div>\n  <h1>Statistics</h1>\n  <h2>A bit ... anal, are you?</h2>\n\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <div class=\"stat-square\">\n          <p class=\"stat-header\">Total Time</p>\n          <h1 class=\"stat\" *ngIf=\"hours[0] !== '0'\">{{hours}}<br>{{minutes}}<br>{{seconds}}</h1>\n          <h1 class=\"stat\" *ngIf=\"hours[0] === '0' && minutes[0] !== '0'\">{{minutes}}<br>{{seconds}}</h1>\n          <h1 class=\"stat\" *ngIf=\"hours[0] === '0' && minutes[0] === '0' && seconds !== '0'\">{{seconds}}</h1>\n        </div>\n      </ion-col>\n      <ion-col>\n        <div class=\"stat-square\">\n          <p class=\"stat-header\">Total Times</p>\n          <h1 class=\"stat\">{{environment.itemCount}}</h1>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col>\n        <div class=\"stat-square\">\n          <p class=\"stat-header\">Total Paid</p>\n          <h1 class=\"stat\">{{totalPaid}}</h1>\n        </div>\n      </ion-col>\n      <ion-col>\n        <div class=\"stat-square\">\n          <p class=\"stat-header\">Day Streak</p>\n          <h1 class=\"stat\">{{environment.streak}} {{environment.streak === 1 ? 'day' : 'days'}}</h1>\n        </div>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col>\n        <div class=\"stat-square\">\n          <p class=\"stat-header\">Shortest Time</p>\n          <h1 class=\"stat\" *ngIf=\"shortestHours[0] !== '0'\">{{shortestHours}}<br>{{shortestMinutes}}<br>{{shortestSeconds}}</h1>\n          <h1 class=\"stat\" *ngIf=\"shortestHours[0] === '0' && shortestMinutes[0] !== '0'\">{{shortestMinutes}}<br>{{shortestSeconds}}</h1>\n          <h1 class=\"stat\" *ngIf=\"shortestHours[0] === '0' && shortestMinutes[0] === '0' && shortestSeconds !== '0'\">{{shortestSeconds}}</h1>\n        </div>\n      </ion-col>\n      <ion-col>\n        <div class=\"stat-square\">\n          <p class=\"stat-header\">Longest Time</p>\n          <h1 class=\"stat\" *ngIf=\"longestHours[0] !== '0'\">{{longestHours}}<br>{{longestMinutes}}<br>{{longestSeconds}}</h1>\n          <h1 class=\"stat\" *ngIf=\"longestHours[0] === '0' && longestMinutes[0] !== '0'\">{{longestMinutes}}<br>{{longestSeconds}}</h1>\n          <h1 class=\"stat\" *ngIf=\"longestHours[0] === '0' && longestMinutes[0] === '0' && longestSeconds !== '0'\">{{longestSeconds}}</h1>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n\n<div id=\"btn-wrapper\">\n  <ion-button color=\"secondary\" id=\"secondary-btn\" (click)=\"goBack()\">BACK</ion-button>\n</div>\n\n";
      /***/
    },

    /***/
    "./src/app/home/statistics/statistics-routing.module.ts":
    /*!**************************************************************!*\
      !*** ./src/app/home/statistics/statistics-routing.module.ts ***!
      \**************************************************************/

    /*! exports provided: StatisticsPageRoutingModule */

    /***/
    function srcAppHomeStatisticsStatisticsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StatisticsPageRoutingModule", function () {
        return StatisticsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _statistics_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./statistics.page */
      "./src/app/home/statistics/statistics.page.ts");

      var routes = [{
        path: '',
        component: _statistics_page__WEBPACK_IMPORTED_MODULE_3__["StatisticsPage"]
      }];

      var StatisticsPageRoutingModule = function StatisticsPageRoutingModule() {
        _classCallCheck(this, StatisticsPageRoutingModule);
      };

      StatisticsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], StatisticsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/home/statistics/statistics.module.ts":
    /*!******************************************************!*\
      !*** ./src/app/home/statistics/statistics.module.ts ***!
      \******************************************************/

    /*! exports provided: StatisticsPageModule */

    /***/
    function srcAppHomeStatisticsStatisticsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StatisticsPageModule", function () {
        return StatisticsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _statistics_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./statistics-routing.module */
      "./src/app/home/statistics/statistics-routing.module.ts");
      /* harmony import */


      var _statistics_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./statistics.page */
      "./src/app/home/statistics/statistics.page.ts");

      var StatisticsPageModule = function StatisticsPageModule() {
        _classCallCheck(this, StatisticsPageModule);
      };

      StatisticsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _statistics_routing_module__WEBPACK_IMPORTED_MODULE_5__["StatisticsPageRoutingModule"]],
        declarations: [_statistics_page__WEBPACK_IMPORTED_MODULE_6__["StatisticsPage"]]
      })], StatisticsPageModule);
      /***/
    },

    /***/
    "./src/app/home/statistics/statistics.page.scss":
    /*!******************************************************!*\
      !*** ./src/app/home/statistics/statistics.page.scss ***!
      \******************************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomeStatisticsStatisticsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "#bar-chart-cont {\n  margin: 32px auto 0px auto;\n  width: 80px;\n}\n\n#chart {\n  color: var(--ion-color-dark);\n  font-size: 80px;\n}\n\nh1 {\n  margin: 0px auto;\n  text-align: center;\n  font-size: 48px;\n  color: var(--ion-color-dark);\n}\n\nh2 {\n  margin: 0px auto 16px auto;\n  text-align: center;\n  font-size: 18px;\n  color: var(--ion-color-secondary);\n}\n\n.stat-square {\n  width: 150px;\n  height: 150px;\n  background: var(--ion-color-primary-super-tint);\n  border-radius: 10px;\n  margin: 0 auto;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n\n.stat-header {\n  width: 150px;\n  text-align: center;\n  font-size: 14px;\n  color: var(--ion-color-secondary);\n  margin: 0px auto;\n}\n\n.stat {\n  width: 150px;\n  font-size: 32px;\n}\n\n#btn-wrapper {\n  margin-bottom: 16px;\n  width: 100%;\n  background: var(--ion-color-background);\n}\n\n#secondary-btn {\n  display: block;\n  width: 90vw;\n  margin: 0 auto;\n  bottom: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9zdGF0aXN0aWNzL3N0YXRpc3RpY3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsMEJBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBRUE7RUFDRSw0QkFBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7QUFDRjs7QUFFQTtFQUNFLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUNBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsK0NBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGlDQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSx1Q0FBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQUNGIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9zdGF0aXN0aWNzL3N0YXRpc3RpY3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2Jhci1jaGFydC1jb250IHtcclxuICBtYXJnaW46IDMycHggYXV0byAwcHggYXV0bztcclxuICB3aWR0aDogODBweDtcclxufVxyXG5cclxuI2NoYXJ0IHtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gIGZvbnQtc2l6ZTogODBweDtcclxufVxyXG5cclxuaDEge1xyXG4gIG1hcmdpbjogMHB4IGF1dG87XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogNDhweDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG59XHJcblxyXG5oMiB7XHJcbiAgbWFyZ2luOiAwcHggYXV0byAxNnB4IGF1dG87XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbn1cclxuXHJcbi5zdGF0LXNxdWFyZSB7XHJcbiAgd2lkdGg6IDE1MHB4O1xyXG4gIGhlaWdodDogMTUwcHg7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktc3VwZXItdGludCk7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbi5zdGF0LWhlYWRlciB7XHJcbiAgd2lkdGg6IDE1MHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gIG1hcmdpbjogMHB4IGF1dG87XHJcbn1cclxuXHJcbi5zdGF0IHtcclxuICB3aWR0aDogMTUwcHg7XHJcbiAgZm9udC1zaXplOiAzMnB4O1xyXG59XHJcblxyXG4jYnRuLXdyYXBwZXIge1xyXG4gIG1hcmdpbi1ib3R0b206IDE2cHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWJhY2tncm91bmQpO1xyXG59XHJcblxyXG4jc2Vjb25kYXJ5LWJ0biB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgd2lkdGg6IDkwdnc7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgYm90dG9tOiAzMnB4O1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/home/statistics/statistics.page.ts":
    /*!****************************************************!*\
      !*** ./src/app/home/statistics/statistics.page.ts ***!
      \****************************************************/

    /*! exports provided: StatisticsPage */

    /***/
    function srcAppHomeStatisticsStatisticsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "StatisticsPage", function () {
        return StatisticsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _services_data_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../services/data-service.service */
      "./src/app/services/data-service.service.ts");
      /* harmony import */


      var src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/environment-storage.service */
      "./src/app/services/environment-storage.service.ts");

      var StatisticsPage = /*#__PURE__*/function () {
        function StatisticsPage(router, dataService, environmentStorageService) {
          _classCallCheck(this, StatisticsPage);

          this.router = router;
          this.dataService = dataService;
          this.environmentStorageService = environmentStorageService;
        }

        _createClass(StatisticsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.environment = this.dataService.environment;
            this.formatTotalTime();
            this.calculateTotalPaid();
            this.formatShortestTime();
            this.formatLongestTime();
          }
        }, {
          key: "formatTotalTime",
          value: function formatTotalTime() {
            var time = this.environment.totalTime * 1000;
            var digitalTime = new Date(time).toISOString().substr(11, 8);
            var hours = digitalTime[0] === '0' ? digitalTime.substr(1, 1) : digitalTime.substr(0, 2);
            var minutes = digitalTime[3] === '0' ? digitalTime.substr(4, 1) : digitalTime.substr(3, 2);
            var seconds = digitalTime[6] === '0' ? digitalTime.substr(7, 1) : digitalTime.substr(6, 2);
            this.hours = hours.length === 1 && hours[0] === '1' ? hours + ' hr' : hours + ' hrs';
            this.minutes = minutes.length === 1 && minutes[0] === '1' ? minutes + ' min' : minutes + ' mins';
            this.seconds = seconds.length === 1 && seconds[0] === '1' ? seconds + ' sec' : seconds + ' secs';
          }
        }, {
          key: "calculateTotalPaid",
          value: function calculateTotalPaid() {
            var symbol = this.environment.currency.slice(0, 1);

            if (this.environment.totalPaid) {
              var total = this.environment.totalPaid.toFixed(2);
              this.totalPaid = symbol + total;
            } else {
              this.totalPaid = symbol + 0;
            }
          }
        }, {
          key: "formatShortestTime",
          value: function formatShortestTime() {
            var time = this.environment.shortestTime * 1000;
            var digitalTime = new Date(time).toISOString().substr(11, 8);
            var hours = digitalTime[0] === '0' ? digitalTime.substr(1, 1) : digitalTime.substr(0, 2);
            var minutes = digitalTime[3] === '0' ? digitalTime.substr(4, 1) : digitalTime.substr(3, 2);
            var seconds = digitalTime[6] === '0' ? digitalTime.substr(7, 1) : digitalTime.substr(6, 2);
            this.shortestHours = hours.length === 1 && hours[0] === '1' ? hours + ' hr' : hours + ' hrs';
            this.shortestMinutes = minutes.length === 1 && minutes[0] === '1' ? minutes + ' min' : minutes + ' mins';
            this.shortestSeconds = seconds.length === 1 && seconds[0] === '1' ? seconds + ' sec' : seconds + ' secs';
          }
        }, {
          key: "formatLongestTime",
          value: function formatLongestTime() {
            var time = this.environment.longestTime * 1000;
            var digitalTime = new Date(time).toISOString().substr(11, 8);
            var hours = digitalTime[0] === '0' ? digitalTime.substr(1, 1) : digitalTime.substr(0, 2);
            var minutes = digitalTime[3] === '0' ? digitalTime.substr(4, 1) : digitalTime.substr(3, 2);
            var seconds = digitalTime[6] === '0' ? digitalTime.substr(7, 1) : digitalTime.substr(6, 2);
            this.longestHours = hours.length === 1 && hours[0] === '1' ? hours + ' hr' : hours + ' hrs';
            this.longestMinutes = minutes.length === 1 && minutes[0] === '1' ? minutes + ' min' : minutes + ' mins';
            this.longestSeconds = seconds.length === 1 && seconds[0] === '1' ? seconds + ' sec' : seconds + ' secs';
          }
        }, {
          key: "goBack",
          value: function goBack() {
            this.router.navigate(['/home']);
          }
        }]);

        return StatisticsPage;
      }();

      StatisticsPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _services_data_service_service__WEBPACK_IMPORTED_MODULE_3__["DataServiceService"]
        }, {
          type: src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_4__["EnvironmentStorageService"]
        }];
      };

      StatisticsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-statistics',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./statistics.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/statistics/statistics.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./statistics.page.scss */
        "./src/app/home/statistics/statistics.page.scss"))["default"]]
      })], StatisticsPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=statistics-statistics-module-es5.js.map