(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["initial-setup-initial-setup-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/initial-setup/initial-setup.page.html":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/initial-setup/initial-setup.page.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppInitialSetupInitialSetupPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n  <h1>Initial Setup</h1>\n  <p id=\"sub-heading\">First things first</p>\n\n  <form #initialSetupForm=\"ngForm\" (ngSubmit)=\"onSubmit(initialSetupForm)\">\n    <!-- name -->\n    <ion-item>\n      <ion-label\n        class=\"label\" \n        position=\"stacked\"\n        text-wrap\n      >What would you like us to call you?</ion-label>\n      <ion-input\n        type=\"text\"\n        placeholder=\"Enter your name/alias\"\n        name=\"name\"\n        [(ngModel)]=\"name\"\n        value=\"string\"\n        required\n      >\n      </ion-input>\n    </ion-item>\n\n    <!-- Hourly Rate -->\n    <ion-item>\n      <ion-label\n        class=\"label\"\n        position=\"stacked\"\n        text-wrap\n      >And how much do you get paid hourly?</ion-label>\n      <ion-input\n        type=\"number\"\n        placeholder=\"Enter hourly wage\"\n        name=\"wage\"\n        [(ngModel)]=\"wage\"\n        value=\"string\"\n        required\n      >\n      </ion-input>\n    </ion-item>\n\n    <!-- currency -->\n    <ion-item>\n      <ion-label\n        class=\"label\"\n        position=\"stacked\"\n        text-wrap\n      >And what currency is that in?</ion-label>\n      <ion-select\n        type=\"search\"\n        placeholder=\"Choose currency\"\n        name=\"currency\"\n        [(ngModel)]=\"currency\"\n        value=\"string\"\n        interface=\"popover\"\n        required\n      >\n        <ion-select-option value=\"£ Pieces of Unicorn Dust\">Unicorn Dust</ion-select-option>\n        <ion-select-option value=\"$ Pieces of Eight\">Pieces of Eight</ion-select-option>\n        <ion-select-option value=\"£ Old Money Pounds\">Old Money</ion-select-option>\n        <ion-select-option value=\"£\">£ Pounds</ion-select-option>\n        <ion-select-option value=\"$\">$ Dollars</ion-select-option>\n        <ion-select-option value=\"€\">€ Euros</ion-select-option>\n      </ion-select>\n    </ion-item>\n\n      <div id=\"btn-wrapper\">\n        <ion-button\n          type=\"submit\"\n          color=\"primary\"\n          id=\"primary-btn\"\n        >NEXT</ion-button>\n      </div>\n  </form>\n  \n</ion-content>\n\n\n\n\n";
      /***/
    },

    /***/
    "./src/app/initial-setup/initial-setup-routing.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/initial-setup/initial-setup-routing.module.ts ***!
      \***************************************************************/

    /*! exports provided: InitialSetupPageRoutingModule */

    /***/
    function srcAppInitialSetupInitialSetupRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InitialSetupPageRoutingModule", function () {
        return InitialSetupPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _initial_setup_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./initial-setup.page */
      "./src/app/initial-setup/initial-setup.page.ts");

      var routes = [{
        path: '',
        component: _initial_setup_page__WEBPACK_IMPORTED_MODULE_3__["InitialSetupPage"]
      }];

      var InitialSetupPageRoutingModule = function InitialSetupPageRoutingModule() {
        _classCallCheck(this, InitialSetupPageRoutingModule);
      };

      InitialSetupPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], InitialSetupPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/initial-setup/initial-setup.module.ts":
    /*!*******************************************************!*\
      !*** ./src/app/initial-setup/initial-setup.module.ts ***!
      \*******************************************************/

    /*! exports provided: InitialSetupPageModule */

    /***/
    function srcAppInitialSetupInitialSetupModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InitialSetupPageModule", function () {
        return InitialSetupPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _initial_setup_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./initial-setup-routing.module */
      "./src/app/initial-setup/initial-setup-routing.module.ts");
      /* harmony import */


      var _initial_setup_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./initial-setup.page */
      "./src/app/initial-setup/initial-setup.page.ts");

      var InitialSetupPageModule = function InitialSetupPageModule() {
        _classCallCheck(this, InitialSetupPageModule);
      };

      InitialSetupPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _initial_setup_routing_module__WEBPACK_IMPORTED_MODULE_5__["InitialSetupPageRoutingModule"]],
        declarations: [_initial_setup_page__WEBPACK_IMPORTED_MODULE_6__["InitialSetupPage"]]
      })], InitialSetupPageModule);
      /***/
    },

    /***/
    "./src/app/initial-setup/initial-setup.page.scss":
    /*!*******************************************************!*\
      !*** ./src/app/initial-setup/initial-setup.page.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function srcAppInitialSetupInitialSetupPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "h1 {\n  font-size: 48px;\n  color: var(--ion-color-secondary);\n  margin: 32px auto 0px auto;\n  text-align: center;\n  line-height: 45px;\n}\n\n#sub-heading {\n  font-size: 18px;\n  color: var(--ion-color-dark);\n  margin: 0px auto 16px auto;\n  text-align: center;\n}\n\nion-item {\n  --background: var(--ion-color-primary-tint);\n  --border-color: var(--ion-color-secondary);\n  margin-bottom: 0px;\n  font-size: 34px;\n}\n\n.label {\n  font-size: 32px;\n  color: var(--ion-color-secondary);\n  margin-bottom: 8px;\n}\n\n#btn-wrapper {\n  margin: 32px auto;\n  width: 100%;\n  background: var(--ion-color-background);\n  z-index: 15;\n}\n\n#primary-btn {\n  display: block;\n  width: 90vw;\n  margin: 0 auto;\n  bottom: 32px;\n  z-index: 100;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaW5pdGlhbC1zZXR1cC9pbml0aWFsLXNldHVwLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxpQ0FBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLDRCQUFBO0VBQ0EsMEJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsMkNBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGlDQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLHVDQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFDRiIsImZpbGUiOiJzcmMvYXBwL2luaXRpYWwtc2V0dXAvaW5pdGlhbC1zZXR1cC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoMXtcclxuICBmb250LXNpemU6IDQ4cHg7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gIG1hcmdpbjogMzJweCBhdXRvIDBweCBhdXRvO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBsaW5lLWhlaWdodDogNDVweDtcclxufVxyXG5cclxuI3N1Yi1oZWFkaW5nIHtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICBtYXJnaW46IDBweCBhdXRvIDE2cHggYXV0bztcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXRpbnQpO1xyXG4gIC0tYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcclxuICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgZm9udC1zaXplOiAzNHB4O1xyXG59XHJcblxyXG4ubGFiZWwge1xyXG4gIGZvbnQtc2l6ZTogMzJweDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xyXG59XHJcblxyXG4jYnRuLXdyYXBwZXIge1xyXG4gIG1hcmdpbjogMzJweCBhdXRvO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1iYWNrZ3JvdW5kKTtcclxuICB6LWluZGV4OjE1O1xyXG59XHJcblxyXG4jcHJpbWFyeS1idG4ge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHdpZHRoOiA5MHZ3O1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIGJvdHRvbTogMzJweDtcclxuICB6LWluZGV4OiAxMDA7XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/initial-setup/initial-setup.page.ts":
    /*!*****************************************************!*\
      !*** ./src/app/initial-setup/initial-setup.page.ts ***!
      \*****************************************************/

    /*! exports provided: InitialSetupPage */

    /***/
    function srcAppInitialSetupInitialSetupPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InitialSetupPage", function () {
        return InitialSetupPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _services_user_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../services/user-storage.service */
      "./src/app/services/user-storage.service.ts");
      /* harmony import */


      var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! moment */
      "./node_modules/moment/moment.js");
      /* harmony import */


      var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
      /* harmony import */


      var _services_environment_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../services/environment-storage.service */
      "./src/app/services/environment-storage.service.ts");
      /* harmony import */


      var _services_data_service_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../services/data-service.service */
      "./src/app/services/data-service.service.ts");
      /* harmony import */


      var _services_toast_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../services/toast.service */
      "./src/app/services/toast.service.ts");

      var InitialSetupPage = /*#__PURE__*/function () {
        function InitialSetupPage(toastService, router, userStorageService, environmentStorageService, dataService) {
          _classCallCheck(this, InitialSetupPage);

          this.toastService = toastService;
          this.router = router;
          this.userStorageService = userStorageService;
          this.environmentStorageService = environmentStorageService;
          this.dataService = dataService;
        }

        _createClass(InitialSetupPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            if (this.dataService.environment) {
              this.router.navigate(['/home']);
            }
          }
        }, {
          key: "onSubmit",
          value: function onSubmit(form) {
            var _this = this;

            if (form.valid) {
              var userName = form.value.name || 'User';
              var signupDate = moment__WEBPACK_IMPORTED_MODULE_4__["now"]();
              var hourlyRate = form.value.wage || null;
              var currency = form.value.currency || null;
              this.userStorageService.addUser({
                userName: userName,
                signupDate: signupDate,
                activeEnvironmentID: 1
              }).then(function (user) {
                _this.dataService.user = user;

                _this.environmentStorageService.addEnvironment({
                  id: 1,
                  name: 'Poo',
                  firstTimeDate: null,
                  hourlyRate: hourlyRate,
                  currency: currency,
                  longestTime: 0,
                  shortestTime: 0,
                  totalTime: 0,
                  itemCount: 0,
                  totalPaid: 0,
                  lastItemID: 0,
                  lastTimeDate: null,
                  streak: 0
                }).then(function (env) {
                  _this.dataService.environment = env[0];

                  _this.toastService.presentToast('Details saved, you\'re good to go!');

                  _this.router.navigate(['/home']);
                });
              });
              form.reset();
            } else {
              this.toastService.presentToast('Please fill in all information');
            }
          }
        }]);

        return InitialSetupPage;
      }();

      InitialSetupPage.ctorParameters = function () {
        return [{
          type: _services_toast_service__WEBPACK_IMPORTED_MODULE_7__["ToastService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _services_user_storage_service__WEBPACK_IMPORTED_MODULE_3__["UserStorageService"]
        }, {
          type: _services_environment_storage_service__WEBPACK_IMPORTED_MODULE_5__["EnvironmentStorageService"]
        }, {
          type: _services_data_service_service__WEBPACK_IMPORTED_MODULE_6__["DataServiceService"]
        }];
      };

      InitialSetupPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-initial-setup',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./initial-setup.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/initial-setup/initial-setup.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./initial-setup.page.scss */
        "./src/app/initial-setup/initial-setup.page.scss"))["default"]]
      })], InitialSetupPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=initial-setup-initial-setup-module-es5.js.map