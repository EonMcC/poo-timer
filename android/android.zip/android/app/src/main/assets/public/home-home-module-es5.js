(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
    /*!***************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\n\n  <app-poobert></app-poobert>\n\n  <h1 id=\"title\" *ngIf=\"environment\">{{environment.name}} Timer</h1>\n\n  <div id=\"number-wrapper\">\n    <div id=\"inside-number-wrapper\">\n      <p #timer class=\"timer\">{{formatedTime}}</p>\n      <p id=\"money-counter\">{{paid}}</p>\n    </div>\n  </div>\n\n  <p id=\"watermark\">Go on<br><span>Poo Time</span> it!</p>\n\n</ion-content>\n  <div id=\"btn-wrapper\">\n    <ion-button color=\"secondary\" id=\"secondary-btn\" (click)=\"openMenu()\">MENU</ion-button>\n    <ion-button *ngIf=\"!timerRunning\" color=\"primary\" id=\"primary-btn\" (click)=\"handleTimer()\">START</ion-button>\n    <ion-button *ngIf=\"timerRunning\" color=\"danger\" id=\"danger-btn\" (click)=\"handleTimer()\">STOP</ion-button>\n  </div>\n\n<app-menu [menuClick]=\"menuClick\" [environment]=\"environment\"></app-menu>";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/menu/menu.component.html":
    /*!*************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/menu/menu.component.html ***!
      \*************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomeMenuMenuComponentHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-menu class=\"menu\" side=\"start\" menuId=\"first\" content-id=\"main-menu\">\r\n  <p id=\"menu-title\" *ngIf=\"environment\">{{environment.name}} Timer</p>\r\n<ion-content id=\"main-menu\">\r\n  <ion-list id=\"menu-list\" lines=\"none\">\r\n\r\n    <ion-item class=\"menu-item top-menu-item\" (click)=\"navigateTo('/home/profile')\">\r\n      <ion-icon name=\"person\" slot=\"start\" size=\"large\"></ion-icon>\r\n      Profile\r\n      <ion-icon class=\"chevron\" name=\"chevron-forward\" slot=\"end\" size=\"large\"></ion-icon>\r\n    </ion-item>\r\n\r\n\r\n    <ion-item (click)=\"navigateTo('/home/settings')\" class=\"menu-item top-menu-item\">\r\n      <ion-icon name=\"settings\" slot=\"start\" size=\"large\"></ion-icon>\r\n      Settings\r\n      <ion-icon class=\"chevron\" name=\"chevron-forward\" slot=\"end\" size=\"large\"></ion-icon>\r\n    </ion-item>\r\n\r\n    <ion-item (click)=\"navigateTo('/home/statistics')\" class=\"menu-item top-menu-item\">\r\n      <ion-icon name=\"bar-chart\" slot=\"start\" size=\"large\"></ion-icon>\r\n      Statistics\r\n      <ion-icon class=\"chevron\" name=\"chevron-forward\" slot=\"end\" size=\"large\"></ion-icon>\r\n    </ion-item>\r\n\r\n  </ion-list>\r\n\r\n  <p id=\"watermark\">Have<br> you <span>Poo Timed</span> it yet?</p>\r\n\r\n  <ion-list id=\"menu-list-bottom\" lines=\"none\" (click)=\"navigateTo('/environment-select')\">\r\n    <ion-item class=\"menu-item menu-item-bottom\">\r\n      <ion-icon name=\"swap-horizontal-outline\" slot=\"start\" size=\"large\"></ion-icon>\r\n      Environments\r\n      <ion-icon class=\"chevron\" name=\"chevron-forward\" slot=\"end\" size=\"large\"></ion-icon>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n</ion-menu>";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/poobert/poobert.component.html":
    /*!*******************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/poobert/poobert.component.html ***!
      \*******************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomePoobertPoobertComponentHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div [ngSwitch]=\"poobertEmotion\">\n  \n  <svg id=\"shadow\" *ngSwitchCase=\"'normal'\" width=\"252\" height=\"255\" viewBox=\"0 0 252 255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n    <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n    <g filter=\"url(#filter0_d)\">\n    <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n    </g>\n    <circle cx=\"128.213\" cy=\"53.2132\" r=\"15\" transform=\"rotate(45 128.213 53.2132)\" fill=\"black\"/>\n    <circle cx=\"128\" cy=\"46\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n    <g filter=\"url(#filter1_d)\">\n    <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n    </g>\n    <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n    <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n    <path d=\"M131 126.5C126.932 129.806 105.53 128.834 100.304 122.405C95.0789 115.977 96.9325 96.3062 101 93C105.068 89.6937 109.809 104.004 115.034 110.432C120.259 116.861 135.068 123.194 131 126.5Z\" fill=\"black\"/>\n    <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"86\" y=\"90\" width=\"47\" height=\"50\">\n    <path d=\"M131 126.5C126.932 129.806 105.53 128.834 100.304 122.405C95.0789 115.977 96.9325 96.3062 101 93C105.068 89.6937 109.809 104.004 115.034 110.432C120.259 116.861 135.068 123.194 131 126.5Z\" fill=\"black\"/>\n    </mask>\n    <g mask=\"url(#mask0)\">\n    <rect x=\"113.984\" y=\"106.131\" width=\"8\" height=\"7.59286\" rx=\"2\" transform=\"rotate(50.8943 113.984 106.131)\" fill=\"white\"/>\n    <rect x=\"121.48\" y=\"111.636\" width=\"8\" height=\"9.93782\" rx=\"3\" transform=\"rotate(50.8943 121.48 111.636)\" fill=\"white\"/>\n    <rect x=\"109.151\" y=\"98.4614\" width=\"8\" height=\"8.67977\" rx=\"3\" transform=\"rotate(50.8943 109.151 98.4614)\" fill=\"white\"/>\n    </g>\n    <defs>\n    <filter id=\"filter0_d\" x=\"94\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n    <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n    <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n    <feOffset dy=\"4\"/>\n    <feGaussianBlur stdDeviation=\"2\"/>\n    <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n    <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n    <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n    </filter>\n    <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n    <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n    <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n    <feOffset dy=\"4\"/>\n    <feGaussianBlur stdDeviation=\"2\"/>\n    <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n    <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n    <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n    </filter>\n    <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n    <stop stop-color=\"#895E3B\"/>\n    <stop offset=\"1\" stop-color=\"#6B401D\"/>\n    </linearGradient>\n    </defs>\n  </svg>\n\n  <div *ngSwitchCase=\"'streak'\">\n    <svg id=\"shadow\" width=\"252\" height=\"255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n      <g filter=\"url(#filter0_d)\">\n      <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"128.213\" cy=\"53.2132\" r=\"15\" transform=\"rotate(45 128.213 53.2132)\" fill=\"black\"/>\n      <circle cx=\"128\" cy=\"46\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n      <g filter=\"url(#filter1_d)\">\n      <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n      <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n      <ellipse cx=\"108.944\" cy=\"115.944\" rx=\"16.74\" ry=\"15\" transform=\"rotate(50.8943 108.944 115.944)\" fill=\"black\"/>\n      <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"86\" y=\"93\" width=\"46\" height=\"46\">\n      <ellipse cx=\"108.944\" cy=\"115.944\" rx=\"16.74\" ry=\"15\" transform=\"rotate(50.8943 108.944 115.944)\" fill=\"black\"/>\n      </mask>\n      <g mask=\"url(#mask0)\">\n      <rect x=\"120.389\" y=\"101.486\" width=\"8\" height=\"12\" rx=\"2\" transform=\"rotate(50.8943 120.389 101.486)\" fill=\"white\"/>\n      <rect x=\"126.065\" y=\"108.47\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(50.8943 126.065 108.47)\" fill=\"white\"/>\n      <rect x=\"114.712\" y=\"94.5027\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(50.8943 114.712 94.5027)\" fill=\"white\"/>\n      </g>\n      <defs>\n      <filter id=\"filter0_d\" x=\"94\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n      <stop stop-color=\"#895E3B\"/>\n      <stop offset=\"1\" stop-color=\"#6B401D\"/>\n      </linearGradient>\n      </defs>\n    </svg>\n    <div id=\"speech-bubble\">\n      <p>Wow! Your on a {{dataService.environment.streak}} day streak</p>\n      <svg id=\"shadow\" width=\"334\" height=\"247\" viewBox=\"0 0 334 247\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <mask id=\"path-1-inside-1\" fill=\"white\">\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\"/>\n        </mask>\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\" fill=\"white\"/>\n        <path d=\"M263 0L263.939 -0.342761L262.02 0.198419L263 0ZM275.801 33.6224L274.869 33.9859L274.869 33.9859L275.801 33.6224ZM266 94L265.03 93.7551L265.03 93.7551L266 94ZM235.795 152.939L235.169 153.719L236.009 154.393L236.619 153.505L235.795 152.939ZM160.9 155.853L160.252 156.614L160.944 157.204L161.597 156.571L160.9 155.853ZM83.6778 159.087L83.7301 160.085L84.1272 160.064L84.4017 159.777L83.6778 159.087ZM82.9191 159.131L82.3719 159.968L82.6508 160.15L82.9834 160.129L82.9191 159.131ZM55.0809 232.869L55.6281 232.032L55.3492 231.85L55.0166 231.871L55.0809 232.869ZM111.599 236.862L112.176 236.045L111.71 235.716L111.189 235.95L111.599 236.862ZM181.5 234.485L182.14 233.716L181.5 233.183L180.86 233.716L181.5 234.485ZM260.278 228.718L260.549 227.755L259.924 227.579L259.509 228.079L260.278 228.718ZM269.733 230.582L269.946 229.605L269.898 229.594L269.848 229.589L269.733 230.582ZM333.942 188.5L332.943 188.442L332.94 188.5L332.943 188.558L333.942 188.5ZM304.171 148.734L303.175 148.826L303.233 149.452L303.823 149.671L304.171 148.734ZM294.5 87.5L295.467 87.2461L295.467 87.2461L294.5 87.5ZM262.061 0.342761C266.659 12.9469 270.94 23.9174 274.869 33.9859L276.732 33.2588C272.803 23.1894 268.53 12.2379 263.939 -0.342761L262.061 0.342761ZM266.97 94.2449C271.463 76.4505 270.696 52.8033 268.832 33.6911C267.898 24.1176 266.686 15.6493 265.707 9.574C265.218 6.53601 264.786 4.09548 264.477 2.41328C264.323 1.57216 264.199 0.920563 264.113 0.478594C264.07 0.257607 264.037 0.0890213 264.015 -0.0246501C264.004 -0.081486 263.995 -0.124594 263.989 -0.15366C263.986 -0.168193 263.984 -0.179216 263.982 -0.186689C263.982 -0.190425 263.981 -0.193274 263.981 -0.195231C263.981 -0.196209 263.98 -0.197006 263.98 -0.197496C263.98 -0.198069 263.98 -0.198419 263 0C262.02 0.198419 262.02 0.198518 262.02 0.19884C262.02 0.199246 262.02 0.199791 262.02 0.200601C262.021 0.202222 262.021 0.204734 262.022 0.208132C262.023 0.214928 262.025 0.22527 262.028 0.239119C262.034 0.266816 262.042 0.308538 262.053 0.363973C262.075 0.474842 262.107 0.640556 262.15 0.858604C262.234 1.2947 262.357 1.94011 262.51 2.77475C262.817 4.44408 263.246 6.87008 263.733 9.89213C264.707 15.9369 265.913 24.3627 266.841 33.8852C268.702 52.9652 269.434 76.3179 265.03 93.7551L266.97 94.2449ZM236.619 153.505C247.952 136.991 262.031 113.801 266.97 94.2449L265.03 93.7551C260.187 112.934 246.297 135.868 234.97 152.373L236.619 153.505ZM200 142C213.734 142 226.15 146.487 235.169 153.719L236.42 152.158C227.025 144.625 214.161 140 200 140V142ZM161.597 156.571C170.751 147.687 184.537 142 200 142V140C184.061 140 169.761 145.86 160.204 155.136L161.597 156.571ZM124 144C138.293 144 151.157 148.859 160.252 156.614L161.549 155.092C152.069 147.008 138.736 142 124 142V144ZM84.4017 159.777C93.5252 150.205 107.847 144 124 144V142C107.352 142 92.4895 148.393 82.954 158.397L84.4017 159.777ZM82.9834 160.129C83.2317 160.113 83.4806 160.098 83.7301 160.085L83.6256 158.088C83.3682 158.101 83.1112 158.116 82.8548 158.133L82.9834 160.129ZM51 151C62.8947 151 73.8031 154.366 82.3719 159.968L83.4663 158.294C74.5591 152.471 63.2675 149 51 149V151ZM1 191.5C1 169.315 23.1833 151 51 151V149C22.4837 149 -1 167.845 -1 191.5H1ZM51 232C23.1833 232 1 213.685 1 191.5H-1C-1 215.155 22.4837 234 51 234V232ZM55.0166 231.871C53.6918 231.957 52.3522 232 51 232V234C52.3951 234 53.7775 233.955 55.1452 233.867L55.0166 231.871ZM87 241C75.1053 241 64.1968 237.634 55.6281 232.032L54.5337 233.706C63.4409 239.529 74.7325 243 87 243V241ZM111.189 235.95C104.026 239.166 95.7811 241 87 241V243C96.0584 243 104.583 241.108 112.009 237.775L111.189 235.95ZM145 246C132.422 246 120.947 242.236 112.176 236.045L111.022 237.679C120.147 244.12 132.028 248 145 248V246ZM180.86 233.716C171.789 241.279 159.089 246 145 246V248C159.526 248 172.688 243.134 182.14 235.253L180.86 233.716ZM218 246C203.911 246 191.211 241.279 182.14 233.716L180.86 235.253C190.312 243.134 203.474 248 218 248V246ZM259.509 228.079C250.553 238.856 235.333 246 218 246V248C235.859 248 251.669 240.641 261.047 229.357L259.509 228.079ZM269.848 229.589C266.639 229.216 263.53 228.597 260.549 227.755L260.006 229.68C263.09 230.551 266.304 231.191 269.618 231.575L269.848 229.589ZM283 231C278.482 231 274.106 230.514 269.946 229.605L269.519 231.559C273.82 232.499 278.339 233 283 233V231ZM333 190.5C333 212.685 310.817 231 283 231V233C311.516 233 335 214.155 335 190.5H333ZM332.943 188.558C332.981 189.202 333 189.849 333 190.5H335C335 189.81 334.98 189.124 334.94 188.442L332.943 188.558ZM333 186.5C333 187.151 332.981 187.798 332.943 188.442L334.94 188.558C334.98 187.876 335 187.19 335 186.5H333ZM303.823 149.671C321.143 156.111 333 170.253 333 186.5H335C335 169.2 322.398 154.443 304.52 147.796L303.823 149.671ZM293.533 87.7539C298.292 105.889 300.985 125.089 303.175 148.826L305.167 148.642C302.972 124.861 300.268 105.536 295.467 87.2461L293.533 87.7539ZM274.869 33.9859C282.488 53.5107 288.774 69.6224 293.533 87.7539L295.467 87.2461C290.674 68.9847 284.345 52.7667 276.732 33.2588L274.869 33.9859Z\" fill=\"#202020\" mask=\"url(#path-1-inside-1)\"/>\n      </svg>\n        \n    </div>\n  </div>\n    \n  <div *ngSwitchCase=\"'boss'\">\n    <svg id=\"shadow\" width=\"252\" height=\"255\" viewBox=\"0 0 252 255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n      <g filter=\"url(#filter0_d)\">\n      <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"128.213\" cy=\"53.2132\" r=\"15\" transform=\"rotate(45 128.213 53.2132)\" fill=\"black\"/>\n      <circle cx=\"128\" cy=\"46\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n      <g filter=\"url(#filter1_d)\">\n      <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n      <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n      <path d=\"M115.953 132.852C109.498 138.045 111.009 126.707 104.911 119.127C98.8124 111.548 87.4142 110.596 93.8687 105.403C100.323 100.21 110.499 102.145 116.598 109.724C122.696 117.304 122.407 127.658 115.953 132.852Z\" fill=\"black\"/>\n      <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"91\" y=\"96\" width=\"37\" height=\"40\">\n      <path d=\"M115.953 132.852C109.498 138.045 111.009 126.707 104.911 119.127C98.8124 111.548 87.4142 110.596 93.8687 105.403C100.323 100.21 110.499 102.145 116.598 109.724C122.696 117.304 122.407 127.658 115.953 132.852Z\" fill=\"black\"/>\n      </mask>\n      <g mask=\"url(#mask0)\">\n      <rect x=\"116.428\" y=\"104.727\" width=\"8\" height=\"12\" rx=\"2\" transform=\"rotate(51.181 116.428 104.727)\" fill=\"white\"/>\n      <rect x=\"122.07\" y=\"111.739\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(51.181 122.07 111.739)\" fill=\"white\"/>\n      <rect x=\"110.786\" y=\"97.7151\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(51.181 110.786 97.7151)\" fill=\"white\"/>\n      </g>\n      <defs>\n      <filter id=\"filter0_d\" x=\"94.0001\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n      <stop stop-color=\"#895E3B\"/>\n      <stop offset=\"1\" stop-color=\"#6B401D\"/>\n      </linearGradient>\n      </defs>\n    </svg>\n    <div id=\"speech-bubble\">\n      <p>Don't let the boss see me!</p>\n      <svg id=\"shadow\" width=\"334\" height=\"247\" viewBox=\"0 0 334 247\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <mask id=\"path-1-inside-1\" fill=\"white\">\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\"/>\n        </mask>\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\" fill=\"white\"/>\n        <path d=\"M263 0L263.939 -0.342761L262.02 0.198419L263 0ZM275.801 33.6224L274.869 33.9859L274.869 33.9859L275.801 33.6224ZM266 94L265.03 93.7551L265.03 93.7551L266 94ZM235.795 152.939L235.169 153.719L236.009 154.393L236.619 153.505L235.795 152.939ZM160.9 155.853L160.252 156.614L160.944 157.204L161.597 156.571L160.9 155.853ZM83.6778 159.087L83.7301 160.085L84.1272 160.064L84.4017 159.777L83.6778 159.087ZM82.9191 159.131L82.3719 159.968L82.6508 160.15L82.9834 160.129L82.9191 159.131ZM55.0809 232.869L55.6281 232.032L55.3492 231.85L55.0166 231.871L55.0809 232.869ZM111.599 236.862L112.176 236.045L111.71 235.716L111.189 235.95L111.599 236.862ZM181.5 234.485L182.14 233.716L181.5 233.183L180.86 233.716L181.5 234.485ZM260.278 228.718L260.549 227.755L259.924 227.579L259.509 228.079L260.278 228.718ZM269.733 230.582L269.946 229.605L269.898 229.594L269.848 229.589L269.733 230.582ZM333.942 188.5L332.943 188.442L332.94 188.5L332.943 188.558L333.942 188.5ZM304.171 148.734L303.175 148.826L303.233 149.452L303.823 149.671L304.171 148.734ZM294.5 87.5L295.467 87.2461L295.467 87.2461L294.5 87.5ZM262.061 0.342761C266.659 12.9469 270.94 23.9174 274.869 33.9859L276.732 33.2588C272.803 23.1894 268.53 12.2379 263.939 -0.342761L262.061 0.342761ZM266.97 94.2449C271.463 76.4505 270.696 52.8033 268.832 33.6911C267.898 24.1176 266.686 15.6493 265.707 9.574C265.218 6.53601 264.786 4.09548 264.477 2.41328C264.323 1.57216 264.199 0.920563 264.113 0.478594C264.07 0.257607 264.037 0.0890213 264.015 -0.0246501C264.004 -0.081486 263.995 -0.124594 263.989 -0.15366C263.986 -0.168193 263.984 -0.179216 263.982 -0.186689C263.982 -0.190425 263.981 -0.193274 263.981 -0.195231C263.981 -0.196209 263.98 -0.197006 263.98 -0.197496C263.98 -0.198069 263.98 -0.198419 263 0C262.02 0.198419 262.02 0.198518 262.02 0.19884C262.02 0.199246 262.02 0.199791 262.02 0.200601C262.021 0.202222 262.021 0.204734 262.022 0.208132C262.023 0.214928 262.025 0.22527 262.028 0.239119C262.034 0.266816 262.042 0.308538 262.053 0.363973C262.075 0.474842 262.107 0.640556 262.15 0.858604C262.234 1.2947 262.357 1.94011 262.51 2.77475C262.817 4.44408 263.246 6.87008 263.733 9.89213C264.707 15.9369 265.913 24.3627 266.841 33.8852C268.702 52.9652 269.434 76.3179 265.03 93.7551L266.97 94.2449ZM236.619 153.505C247.952 136.991 262.031 113.801 266.97 94.2449L265.03 93.7551C260.187 112.934 246.297 135.868 234.97 152.373L236.619 153.505ZM200 142C213.734 142 226.15 146.487 235.169 153.719L236.42 152.158C227.025 144.625 214.161 140 200 140V142ZM161.597 156.571C170.751 147.687 184.537 142 200 142V140C184.061 140 169.761 145.86 160.204 155.136L161.597 156.571ZM124 144C138.293 144 151.157 148.859 160.252 156.614L161.549 155.092C152.069 147.008 138.736 142 124 142V144ZM84.4017 159.777C93.5252 150.205 107.847 144 124 144V142C107.352 142 92.4895 148.393 82.954 158.397L84.4017 159.777ZM82.9834 160.129C83.2317 160.113 83.4806 160.098 83.7301 160.085L83.6256 158.088C83.3682 158.101 83.1112 158.116 82.8548 158.133L82.9834 160.129ZM51 151C62.8947 151 73.8031 154.366 82.3719 159.968L83.4663 158.294C74.5591 152.471 63.2675 149 51 149V151ZM1 191.5C1 169.315 23.1833 151 51 151V149C22.4837 149 -1 167.845 -1 191.5H1ZM51 232C23.1833 232 1 213.685 1 191.5H-1C-1 215.155 22.4837 234 51 234V232ZM55.0166 231.871C53.6918 231.957 52.3522 232 51 232V234C52.3951 234 53.7775 233.955 55.1452 233.867L55.0166 231.871ZM87 241C75.1053 241 64.1968 237.634 55.6281 232.032L54.5337 233.706C63.4409 239.529 74.7325 243 87 243V241ZM111.189 235.95C104.026 239.166 95.7811 241 87 241V243C96.0584 243 104.583 241.108 112.009 237.775L111.189 235.95ZM145 246C132.422 246 120.947 242.236 112.176 236.045L111.022 237.679C120.147 244.12 132.028 248 145 248V246ZM180.86 233.716C171.789 241.279 159.089 246 145 246V248C159.526 248 172.688 243.134 182.14 235.253L180.86 233.716ZM218 246C203.911 246 191.211 241.279 182.14 233.716L180.86 235.253C190.312 243.134 203.474 248 218 248V246ZM259.509 228.079C250.553 238.856 235.333 246 218 246V248C235.859 248 251.669 240.641 261.047 229.357L259.509 228.079ZM269.848 229.589C266.639 229.216 263.53 228.597 260.549 227.755L260.006 229.68C263.09 230.551 266.304 231.191 269.618 231.575L269.848 229.589ZM283 231C278.482 231 274.106 230.514 269.946 229.605L269.519 231.559C273.82 232.499 278.339 233 283 233V231ZM333 190.5C333 212.685 310.817 231 283 231V233C311.516 233 335 214.155 335 190.5H333ZM332.943 188.558C332.981 189.202 333 189.849 333 190.5H335C335 189.81 334.98 189.124 334.94 188.442L332.943 188.558ZM333 186.5C333 187.151 332.981 187.798 332.943 188.442L334.94 188.558C334.98 187.876 335 187.19 335 186.5H333ZM303.823 149.671C321.143 156.111 333 170.253 333 186.5H335C335 169.2 322.398 154.443 304.52 147.796L303.823 149.671ZM293.533 87.7539C298.292 105.889 300.985 125.089 303.175 148.826L305.167 148.642C302.972 124.861 300.268 105.536 295.467 87.2461L293.533 87.7539ZM274.869 33.9859C282.488 53.5107 288.774 69.6224 293.533 87.7539L295.467 87.2461C290.674 68.9847 284.345 52.7667 276.732 33.2588L274.869 33.9859Z\" fill=\"#202020\" mask=\"url(#path-1-inside-1)\"/>\n      </svg>\n    </div>\n  </div>\n\n  <div *ngSwitchCase=\"'waiting'\">\n    <svg id=\"shadow\" width=\"252\" height=\"255\" viewBox=\"0 0 252 255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n      <g filter=\"url(#filter0_d)\">\n      <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"128.213\" cy=\"53.2132\" r=\"15\" transform=\"rotate(45 128.213 53.2132)\" fill=\"black\"/>\n      <circle cx=\"128\" cy=\"46\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n      <g filter=\"url(#filter1_d)\">\n      <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n      <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n      <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"90\" y=\"96\" width=\"38\" height=\"40\">\n      <path d=\"M115.741 133.111C109.287 138.304 110.797 126.966 104.699 119.386C98.6005 111.807 87.2023 110.855 93.6568 105.662C100.111 100.469 110.287 102.404 116.386 109.983C122.484 117.563 122.196 127.917 115.741 133.111Z\" fill=\"black\"/>\n      </mask>\n      <g mask=\"url(#mask0)\">\n      <rect x=\"116.216\" y=\"104.986\" width=\"8\" height=\"12\" rx=\"2\" transform=\"rotate(51.181 116.216 104.986)\" fill=\"white\"/>\n      <rect x=\"121.858\" y=\"111.998\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(51.181 121.858 111.998)\" fill=\"white\"/>\n      <rect x=\"110.574\" y=\"97.9741\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(51.181 110.574 97.9741)\" fill=\"white\"/>\n      </g>\n      <defs>\n      <filter id=\"filter0_d\" x=\"94\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n      <stop stop-color=\"#895E3B\"/>\n      <stop offset=\"1\" stop-color=\"#6B401D\"/>\n      </linearGradient>\n      </defs>\n    </svg>\n    <div id=\"speech-bubble\">\n      <p>What are you waiting for?</p>\n      <svg id=\"shadow\" width=\"334\" height=\"247\" viewBox=\"0 0 334 247\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <mask id=\"path-1-inside-1\" fill=\"white\">\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\"/>\n        </mask>\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\" fill=\"white\"/>\n        <path d=\"M263 0L263.939 -0.342761L262.02 0.198419L263 0ZM275.801 33.6224L274.869 33.9859L274.869 33.9859L275.801 33.6224ZM266 94L265.03 93.7551L265.03 93.7551L266 94ZM235.795 152.939L235.169 153.719L236.009 154.393L236.619 153.505L235.795 152.939ZM160.9 155.853L160.252 156.614L160.944 157.204L161.597 156.571L160.9 155.853ZM83.6778 159.087L83.7301 160.085L84.1272 160.064L84.4017 159.777L83.6778 159.087ZM82.9191 159.131L82.3719 159.968L82.6508 160.15L82.9834 160.129L82.9191 159.131ZM55.0809 232.869L55.6281 232.032L55.3492 231.85L55.0166 231.871L55.0809 232.869ZM111.599 236.862L112.176 236.045L111.71 235.716L111.189 235.95L111.599 236.862ZM181.5 234.485L182.14 233.716L181.5 233.183L180.86 233.716L181.5 234.485ZM260.278 228.718L260.549 227.755L259.924 227.579L259.509 228.079L260.278 228.718ZM269.733 230.582L269.946 229.605L269.898 229.594L269.848 229.589L269.733 230.582ZM333.942 188.5L332.943 188.442L332.94 188.5L332.943 188.558L333.942 188.5ZM304.171 148.734L303.175 148.826L303.233 149.452L303.823 149.671L304.171 148.734ZM294.5 87.5L295.467 87.2461L295.467 87.2461L294.5 87.5ZM262.061 0.342761C266.659 12.9469 270.94 23.9174 274.869 33.9859L276.732 33.2588C272.803 23.1894 268.53 12.2379 263.939 -0.342761L262.061 0.342761ZM266.97 94.2449C271.463 76.4505 270.696 52.8033 268.832 33.6911C267.898 24.1176 266.686 15.6493 265.707 9.574C265.218 6.53601 264.786 4.09548 264.477 2.41328C264.323 1.57216 264.199 0.920563 264.113 0.478594C264.07 0.257607 264.037 0.0890213 264.015 -0.0246501C264.004 -0.081486 263.995 -0.124594 263.989 -0.15366C263.986 -0.168193 263.984 -0.179216 263.982 -0.186689C263.982 -0.190425 263.981 -0.193274 263.981 -0.195231C263.981 -0.196209 263.98 -0.197006 263.98 -0.197496C263.98 -0.198069 263.98 -0.198419 263 0C262.02 0.198419 262.02 0.198518 262.02 0.19884C262.02 0.199246 262.02 0.199791 262.02 0.200601C262.021 0.202222 262.021 0.204734 262.022 0.208132C262.023 0.214928 262.025 0.22527 262.028 0.239119C262.034 0.266816 262.042 0.308538 262.053 0.363973C262.075 0.474842 262.107 0.640556 262.15 0.858604C262.234 1.2947 262.357 1.94011 262.51 2.77475C262.817 4.44408 263.246 6.87008 263.733 9.89213C264.707 15.9369 265.913 24.3627 266.841 33.8852C268.702 52.9652 269.434 76.3179 265.03 93.7551L266.97 94.2449ZM236.619 153.505C247.952 136.991 262.031 113.801 266.97 94.2449L265.03 93.7551C260.187 112.934 246.297 135.868 234.97 152.373L236.619 153.505ZM200 142C213.734 142 226.15 146.487 235.169 153.719L236.42 152.158C227.025 144.625 214.161 140 200 140V142ZM161.597 156.571C170.751 147.687 184.537 142 200 142V140C184.061 140 169.761 145.86 160.204 155.136L161.597 156.571ZM124 144C138.293 144 151.157 148.859 160.252 156.614L161.549 155.092C152.069 147.008 138.736 142 124 142V144ZM84.4017 159.777C93.5252 150.205 107.847 144 124 144V142C107.352 142 92.4895 148.393 82.954 158.397L84.4017 159.777ZM82.9834 160.129C83.2317 160.113 83.4806 160.098 83.7301 160.085L83.6256 158.088C83.3682 158.101 83.1112 158.116 82.8548 158.133L82.9834 160.129ZM51 151C62.8947 151 73.8031 154.366 82.3719 159.968L83.4663 158.294C74.5591 152.471 63.2675 149 51 149V151ZM1 191.5C1 169.315 23.1833 151 51 151V149C22.4837 149 -1 167.845 -1 191.5H1ZM51 232C23.1833 232 1 213.685 1 191.5H-1C-1 215.155 22.4837 234 51 234V232ZM55.0166 231.871C53.6918 231.957 52.3522 232 51 232V234C52.3951 234 53.7775 233.955 55.1452 233.867L55.0166 231.871ZM87 241C75.1053 241 64.1968 237.634 55.6281 232.032L54.5337 233.706C63.4409 239.529 74.7325 243 87 243V241ZM111.189 235.95C104.026 239.166 95.7811 241 87 241V243C96.0584 243 104.583 241.108 112.009 237.775L111.189 235.95ZM145 246C132.422 246 120.947 242.236 112.176 236.045L111.022 237.679C120.147 244.12 132.028 248 145 248V246ZM180.86 233.716C171.789 241.279 159.089 246 145 246V248C159.526 248 172.688 243.134 182.14 235.253L180.86 233.716ZM218 246C203.911 246 191.211 241.279 182.14 233.716L180.86 235.253C190.312 243.134 203.474 248 218 248V246ZM259.509 228.079C250.553 238.856 235.333 246 218 246V248C235.859 248 251.669 240.641 261.047 229.357L259.509 228.079ZM269.848 229.589C266.639 229.216 263.53 228.597 260.549 227.755L260.006 229.68C263.09 230.551 266.304 231.191 269.618 231.575L269.848 229.589ZM283 231C278.482 231 274.106 230.514 269.946 229.605L269.519 231.559C273.82 232.499 278.339 233 283 233V231ZM333 190.5C333 212.685 310.817 231 283 231V233C311.516 233 335 214.155 335 190.5H333ZM332.943 188.558C332.981 189.202 333 189.849 333 190.5H335C335 189.81 334.98 189.124 334.94 188.442L332.943 188.558ZM333 186.5C333 187.151 332.981 187.798 332.943 188.442L334.94 188.558C334.98 187.876 335 187.19 335 186.5H333ZM303.823 149.671C321.143 156.111 333 170.253 333 186.5H335C335 169.2 322.398 154.443 304.52 147.796L303.823 149.671ZM293.533 87.7539C298.292 105.889 300.985 125.089 303.175 148.826L305.167 148.642C302.972 124.861 300.268 105.536 295.467 87.2461L293.533 87.7539ZM274.869 33.9859C282.488 53.5107 288.774 69.6224 293.533 87.7539L295.467 87.2461C290.674 68.9847 284.345 52.7667 276.732 33.2588L274.869 33.9859Z\" fill=\"#202020\" mask=\"url(#path-1-inside-1)\"/>\n      </svg>\n    </div>\n  </div>\n\n  <div *ngSwitchCase=\"'tap-start'\">\n    <svg id=\"shadow\" width=\"252\" height=\"255\" viewBox=\"0 0 252 255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n      <g filter=\"url(#filter0_d)\">\n      <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"128.213\" cy=\"53.2132\" r=\"15\" transform=\"rotate(45 128.213 53.2132)\" fill=\"black\"/>\n      <circle cx=\"128\" cy=\"46\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n      <g filter=\"url(#filter1_d)\">\n      <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n      <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n      <path d=\"M131 126.5C126.932 129.806 105.53 128.834 100.304 122.405C95.0789 115.977 96.9325 96.3062 101 93C105.068 89.6937 109.809 104.004 115.034 110.432C120.259 116.861 135.068 123.194 131 126.5Z\" fill=\"black\"/>\n      <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"86\" y=\"90\" width=\"47\" height=\"50\">\n      <path d=\"M131 126.5C126.932 129.806 105.53 128.834 100.304 122.405C95.0789 115.977 96.9325 96.3062 101 93C105.068 89.6937 109.809 104.004 115.034 110.432C120.259 116.861 135.068 123.194 131 126.5Z\" fill=\"black\"/>\n      </mask>\n      <g mask=\"url(#mask0)\">\n      <rect x=\"113.984\" y=\"106.131\" width=\"8\" height=\"7.59286\" rx=\"2\" transform=\"rotate(50.8943 113.984 106.131)\" fill=\"white\"/>\n      <rect x=\"121.48\" y=\"111.636\" width=\"8\" height=\"9.93782\" rx=\"3\" transform=\"rotate(50.8943 121.48 111.636)\" fill=\"white\"/>\n      <rect x=\"109.151\" y=\"98.4614\" width=\"8\" height=\"8.67977\" rx=\"3\" transform=\"rotate(50.8943 109.151 98.4614)\" fill=\"white\"/>\n      </g>\n      <defs>\n      <filter id=\"filter0_d\" x=\"94\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n      <stop stop-color=\"#895E3B\"/>\n      <stop offset=\"1\" stop-color=\"#6B401D\"/>\n      </linearGradient>\n      </defs>\n    </svg>\n    <div id=\"speech-bubble\">\n      <p>Just tap START to start</p>\n      <svg id=\"shadow\" width=\"334\" height=\"247\" viewBox=\"0 0 334 247\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <mask id=\"path-1-inside-1\" fill=\"white\">\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\"/>\n        </mask>\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\" fill=\"white\"/>\n        <path d=\"M263 0L263.939 -0.342761L262.02 0.198419L263 0ZM275.801 33.6224L274.869 33.9859L274.869 33.9859L275.801 33.6224ZM266 94L265.03 93.7551L265.03 93.7551L266 94ZM235.795 152.939L235.169 153.719L236.009 154.393L236.619 153.505L235.795 152.939ZM160.9 155.853L160.252 156.614L160.944 157.204L161.597 156.571L160.9 155.853ZM83.6778 159.087L83.7301 160.085L84.1272 160.064L84.4017 159.777L83.6778 159.087ZM82.9191 159.131L82.3719 159.968L82.6508 160.15L82.9834 160.129L82.9191 159.131ZM55.0809 232.869L55.6281 232.032L55.3492 231.85L55.0166 231.871L55.0809 232.869ZM111.599 236.862L112.176 236.045L111.71 235.716L111.189 235.95L111.599 236.862ZM181.5 234.485L182.14 233.716L181.5 233.183L180.86 233.716L181.5 234.485ZM260.278 228.718L260.549 227.755L259.924 227.579L259.509 228.079L260.278 228.718ZM269.733 230.582L269.946 229.605L269.898 229.594L269.848 229.589L269.733 230.582ZM333.942 188.5L332.943 188.442L332.94 188.5L332.943 188.558L333.942 188.5ZM304.171 148.734L303.175 148.826L303.233 149.452L303.823 149.671L304.171 148.734ZM294.5 87.5L295.467 87.2461L295.467 87.2461L294.5 87.5ZM262.061 0.342761C266.659 12.9469 270.94 23.9174 274.869 33.9859L276.732 33.2588C272.803 23.1894 268.53 12.2379 263.939 -0.342761L262.061 0.342761ZM266.97 94.2449C271.463 76.4505 270.696 52.8033 268.832 33.6911C267.898 24.1176 266.686 15.6493 265.707 9.574C265.218 6.53601 264.786 4.09548 264.477 2.41328C264.323 1.57216 264.199 0.920563 264.113 0.478594C264.07 0.257607 264.037 0.0890213 264.015 -0.0246501C264.004 -0.081486 263.995 -0.124594 263.989 -0.15366C263.986 -0.168193 263.984 -0.179216 263.982 -0.186689C263.982 -0.190425 263.981 -0.193274 263.981 -0.195231C263.981 -0.196209 263.98 -0.197006 263.98 -0.197496C263.98 -0.198069 263.98 -0.198419 263 0C262.02 0.198419 262.02 0.198518 262.02 0.19884C262.02 0.199246 262.02 0.199791 262.02 0.200601C262.021 0.202222 262.021 0.204734 262.022 0.208132C262.023 0.214928 262.025 0.22527 262.028 0.239119C262.034 0.266816 262.042 0.308538 262.053 0.363973C262.075 0.474842 262.107 0.640556 262.15 0.858604C262.234 1.2947 262.357 1.94011 262.51 2.77475C262.817 4.44408 263.246 6.87008 263.733 9.89213C264.707 15.9369 265.913 24.3627 266.841 33.8852C268.702 52.9652 269.434 76.3179 265.03 93.7551L266.97 94.2449ZM236.619 153.505C247.952 136.991 262.031 113.801 266.97 94.2449L265.03 93.7551C260.187 112.934 246.297 135.868 234.97 152.373L236.619 153.505ZM200 142C213.734 142 226.15 146.487 235.169 153.719L236.42 152.158C227.025 144.625 214.161 140 200 140V142ZM161.597 156.571C170.751 147.687 184.537 142 200 142V140C184.061 140 169.761 145.86 160.204 155.136L161.597 156.571ZM124 144C138.293 144 151.157 148.859 160.252 156.614L161.549 155.092C152.069 147.008 138.736 142 124 142V144ZM84.4017 159.777C93.5252 150.205 107.847 144 124 144V142C107.352 142 92.4895 148.393 82.954 158.397L84.4017 159.777ZM82.9834 160.129C83.2317 160.113 83.4806 160.098 83.7301 160.085L83.6256 158.088C83.3682 158.101 83.1112 158.116 82.8548 158.133L82.9834 160.129ZM51 151C62.8947 151 73.8031 154.366 82.3719 159.968L83.4663 158.294C74.5591 152.471 63.2675 149 51 149V151ZM1 191.5C1 169.315 23.1833 151 51 151V149C22.4837 149 -1 167.845 -1 191.5H1ZM51 232C23.1833 232 1 213.685 1 191.5H-1C-1 215.155 22.4837 234 51 234V232ZM55.0166 231.871C53.6918 231.957 52.3522 232 51 232V234C52.3951 234 53.7775 233.955 55.1452 233.867L55.0166 231.871ZM87 241C75.1053 241 64.1968 237.634 55.6281 232.032L54.5337 233.706C63.4409 239.529 74.7325 243 87 243V241ZM111.189 235.95C104.026 239.166 95.7811 241 87 241V243C96.0584 243 104.583 241.108 112.009 237.775L111.189 235.95ZM145 246C132.422 246 120.947 242.236 112.176 236.045L111.022 237.679C120.147 244.12 132.028 248 145 248V246ZM180.86 233.716C171.789 241.279 159.089 246 145 246V248C159.526 248 172.688 243.134 182.14 235.253L180.86 233.716ZM218 246C203.911 246 191.211 241.279 182.14 233.716L180.86 235.253C190.312 243.134 203.474 248 218 248V246ZM259.509 228.079C250.553 238.856 235.333 246 218 246V248C235.859 248 251.669 240.641 261.047 229.357L259.509 228.079ZM269.848 229.589C266.639 229.216 263.53 228.597 260.549 227.755L260.006 229.68C263.09 230.551 266.304 231.191 269.618 231.575L269.848 229.589ZM283 231C278.482 231 274.106 230.514 269.946 229.605L269.519 231.559C273.82 232.499 278.339 233 283 233V231ZM333 190.5C333 212.685 310.817 231 283 231V233C311.516 233 335 214.155 335 190.5H333ZM332.943 188.558C332.981 189.202 333 189.849 333 190.5H335C335 189.81 334.98 189.124 334.94 188.442L332.943 188.558ZM333 186.5C333 187.151 332.981 187.798 332.943 188.442L334.94 188.558C334.98 187.876 335 187.19 335 186.5H333ZM303.823 149.671C321.143 156.111 333 170.253 333 186.5H335C335 169.2 322.398 154.443 304.52 147.796L303.823 149.671ZM293.533 87.7539C298.292 105.889 300.985 125.089 303.175 148.826L305.167 148.642C302.972 124.861 300.268 105.536 295.467 87.2461L293.533 87.7539ZM274.869 33.9859C282.488 53.5107 288.774 69.6224 293.533 87.7539L295.467 87.2461C290.674 68.9847 284.345 52.7667 276.732 33.2588L274.869 33.9859Z\" fill=\"#202020\" mask=\"url(#path-1-inside-1)\"/>\n      </svg>\n    </div>\n  </div>\n\n  <div *ngSwitchCase=\"'ima-poo'\">\n    <svg id=\"shadow\" width=\"252\" height=\"255\" viewBox=\"0 0 252 255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n      <g filter=\"url(#filter0_d)\">\n      <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"128.213\" cy=\"53.2132\" r=\"15\" transform=\"rotate(45 128.213 53.2132)\" fill=\"black\"/>\n      <circle cx=\"128\" cy=\"46\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n      <g filter=\"url(#filter1_d)\">\n      <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n      <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n      <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"90\" y=\"96\" width=\"38\" height=\"40\">\n      <path d=\"M115.741 133.111C109.287 138.304 110.797 126.966 104.699 119.386C98.6005 111.807 87.2023 110.855 93.6568 105.662C100.111 100.469 110.287 102.404 116.386 109.983C122.484 117.563 122.196 127.917 115.741 133.111Z\" fill=\"black\"/>\n      </mask>\n      <g mask=\"url(#mask0)\">\n      <rect x=\"116.216\" y=\"104.986\" width=\"8\" height=\"12\" rx=\"2\" transform=\"rotate(51.181 116.216 104.986)\" fill=\"white\"/>\n      <rect x=\"121.858\" y=\"111.998\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(51.181 121.858 111.998)\" fill=\"white\"/>\n      <rect x=\"110.574\" y=\"97.9741\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(51.181 110.574 97.9741)\" fill=\"white\"/>\n      </g>\n      <defs>\n      <filter id=\"filter0_d\" x=\"94\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n      <stop stop-color=\"#895E3B\"/>\n      <stop offset=\"1\" stop-color=\"#6B401D\"/>\n      </linearGradient>\n      </defs>\n    </svg>\n    <div id=\"speech-bubble\">\n      <p>I'm a poo, in case you couldn't tell</p>\n      <svg id=\"shadow\" width=\"334\" height=\"247\" viewBox=\"0 0 334 247\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <mask id=\"path-1-inside-1\" fill=\"white\">\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\"/>\n        </mask>\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\" fill=\"white\"/>\n        <path d=\"M263 0L263.939 -0.342761L262.02 0.198419L263 0ZM275.801 33.6224L274.869 33.9859L274.869 33.9859L275.801 33.6224ZM266 94L265.03 93.7551L265.03 93.7551L266 94ZM235.795 152.939L235.169 153.719L236.009 154.393L236.619 153.505L235.795 152.939ZM160.9 155.853L160.252 156.614L160.944 157.204L161.597 156.571L160.9 155.853ZM83.6778 159.087L83.7301 160.085L84.1272 160.064L84.4017 159.777L83.6778 159.087ZM82.9191 159.131L82.3719 159.968L82.6508 160.15L82.9834 160.129L82.9191 159.131ZM55.0809 232.869L55.6281 232.032L55.3492 231.85L55.0166 231.871L55.0809 232.869ZM111.599 236.862L112.176 236.045L111.71 235.716L111.189 235.95L111.599 236.862ZM181.5 234.485L182.14 233.716L181.5 233.183L180.86 233.716L181.5 234.485ZM260.278 228.718L260.549 227.755L259.924 227.579L259.509 228.079L260.278 228.718ZM269.733 230.582L269.946 229.605L269.898 229.594L269.848 229.589L269.733 230.582ZM333.942 188.5L332.943 188.442L332.94 188.5L332.943 188.558L333.942 188.5ZM304.171 148.734L303.175 148.826L303.233 149.452L303.823 149.671L304.171 148.734ZM294.5 87.5L295.467 87.2461L295.467 87.2461L294.5 87.5ZM262.061 0.342761C266.659 12.9469 270.94 23.9174 274.869 33.9859L276.732 33.2588C272.803 23.1894 268.53 12.2379 263.939 -0.342761L262.061 0.342761ZM266.97 94.2449C271.463 76.4505 270.696 52.8033 268.832 33.6911C267.898 24.1176 266.686 15.6493 265.707 9.574C265.218 6.53601 264.786 4.09548 264.477 2.41328C264.323 1.57216 264.199 0.920563 264.113 0.478594C264.07 0.257607 264.037 0.0890213 264.015 -0.0246501C264.004 -0.081486 263.995 -0.124594 263.989 -0.15366C263.986 -0.168193 263.984 -0.179216 263.982 -0.186689C263.982 -0.190425 263.981 -0.193274 263.981 -0.195231C263.981 -0.196209 263.98 -0.197006 263.98 -0.197496C263.98 -0.198069 263.98 -0.198419 263 0C262.02 0.198419 262.02 0.198518 262.02 0.19884C262.02 0.199246 262.02 0.199791 262.02 0.200601C262.021 0.202222 262.021 0.204734 262.022 0.208132C262.023 0.214928 262.025 0.22527 262.028 0.239119C262.034 0.266816 262.042 0.308538 262.053 0.363973C262.075 0.474842 262.107 0.640556 262.15 0.858604C262.234 1.2947 262.357 1.94011 262.51 2.77475C262.817 4.44408 263.246 6.87008 263.733 9.89213C264.707 15.9369 265.913 24.3627 266.841 33.8852C268.702 52.9652 269.434 76.3179 265.03 93.7551L266.97 94.2449ZM236.619 153.505C247.952 136.991 262.031 113.801 266.97 94.2449L265.03 93.7551C260.187 112.934 246.297 135.868 234.97 152.373L236.619 153.505ZM200 142C213.734 142 226.15 146.487 235.169 153.719L236.42 152.158C227.025 144.625 214.161 140 200 140V142ZM161.597 156.571C170.751 147.687 184.537 142 200 142V140C184.061 140 169.761 145.86 160.204 155.136L161.597 156.571ZM124 144C138.293 144 151.157 148.859 160.252 156.614L161.549 155.092C152.069 147.008 138.736 142 124 142V144ZM84.4017 159.777C93.5252 150.205 107.847 144 124 144V142C107.352 142 92.4895 148.393 82.954 158.397L84.4017 159.777ZM82.9834 160.129C83.2317 160.113 83.4806 160.098 83.7301 160.085L83.6256 158.088C83.3682 158.101 83.1112 158.116 82.8548 158.133L82.9834 160.129ZM51 151C62.8947 151 73.8031 154.366 82.3719 159.968L83.4663 158.294C74.5591 152.471 63.2675 149 51 149V151ZM1 191.5C1 169.315 23.1833 151 51 151V149C22.4837 149 -1 167.845 -1 191.5H1ZM51 232C23.1833 232 1 213.685 1 191.5H-1C-1 215.155 22.4837 234 51 234V232ZM55.0166 231.871C53.6918 231.957 52.3522 232 51 232V234C52.3951 234 53.7775 233.955 55.1452 233.867L55.0166 231.871ZM87 241C75.1053 241 64.1968 237.634 55.6281 232.032L54.5337 233.706C63.4409 239.529 74.7325 243 87 243V241ZM111.189 235.95C104.026 239.166 95.7811 241 87 241V243C96.0584 243 104.583 241.108 112.009 237.775L111.189 235.95ZM145 246C132.422 246 120.947 242.236 112.176 236.045L111.022 237.679C120.147 244.12 132.028 248 145 248V246ZM180.86 233.716C171.789 241.279 159.089 246 145 246V248C159.526 248 172.688 243.134 182.14 235.253L180.86 233.716ZM218 246C203.911 246 191.211 241.279 182.14 233.716L180.86 235.253C190.312 243.134 203.474 248 218 248V246ZM259.509 228.079C250.553 238.856 235.333 246 218 246V248C235.859 248 251.669 240.641 261.047 229.357L259.509 228.079ZM269.848 229.589C266.639 229.216 263.53 228.597 260.549 227.755L260.006 229.68C263.09 230.551 266.304 231.191 269.618 231.575L269.848 229.589ZM283 231C278.482 231 274.106 230.514 269.946 229.605L269.519 231.559C273.82 232.499 278.339 233 283 233V231ZM333 190.5C333 212.685 310.817 231 283 231V233C311.516 233 335 214.155 335 190.5H333ZM332.943 188.558C332.981 189.202 333 189.849 333 190.5H335C335 189.81 334.98 189.124 334.94 188.442L332.943 188.558ZM333 186.5C333 187.151 332.981 187.798 332.943 188.442L334.94 188.558C334.98 187.876 335 187.19 335 186.5H333ZM303.823 149.671C321.143 156.111 333 170.253 333 186.5H335C335 169.2 322.398 154.443 304.52 147.796L303.823 149.671ZM293.533 87.7539C298.292 105.889 300.985 125.089 303.175 148.826L305.167 148.642C302.972 124.861 300.268 105.536 295.467 87.2461L293.533 87.7539ZM274.869 33.9859C282.488 53.5107 288.774 69.6224 293.533 87.7539L295.467 87.2461C290.674 68.9847 284.345 52.7667 276.732 33.2588L274.869 33.9859Z\" fill=\"#202020\" mask=\"url(#path-1-inside-1)\"/>\n      </svg>\n    </div>\n  </div>\n\n  <div *ngSwitchCase=\"'longest'\">\n    <svg id=\"shadow\" width=\"252\" height=\"255\" viewBox=\"0 0 252 255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n      <g filter=\"url(#filter0_d)\">\n      <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"128.213\" cy=\"53.2132\" r=\"15\" transform=\"rotate(45 128.213 53.2132)\" fill=\"black\"/>\n      <circle cx=\"128\" cy=\"46\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n      <g filter=\"url(#filter1_d)\">\n      <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n      <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n      <ellipse cx=\"108.944\" cy=\"115.944\" rx=\"16.74\" ry=\"15\" transform=\"rotate(50.8943 108.944 115.944)\" fill=\"black\"/>\n      <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"86\" y=\"93\" width=\"46\" height=\"46\">\n      <ellipse cx=\"108.944\" cy=\"115.944\" rx=\"16.74\" ry=\"15\" transform=\"rotate(50.8943 108.944 115.944)\" fill=\"black\"/>\n      </mask>\n      <g mask=\"url(#mask0)\">\n      <rect x=\"120.389\" y=\"101.486\" width=\"8\" height=\"12\" rx=\"2\" transform=\"rotate(50.8943 120.389 101.486)\" fill=\"white\"/>\n      <rect x=\"126.065\" y=\"108.47\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(50.8943 126.065 108.47)\" fill=\"white\"/>\n      <rect x=\"114.712\" y=\"94.5027\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(50.8943 114.712 94.5027)\" fill=\"white\"/>\n      </g>\n      <defs>\n      <filter id=\"filter0_d\" x=\"94\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n      <stop stop-color=\"#895E3B\"/>\n      <stop offset=\"1\" stop-color=\"#6B401D\"/>\n      </linearGradient>\n      </defs>\n    </svg>\n    <div id=\"speech-bubble\">\n      <p>This is your longest time!</p>\n      <svg id=\"shadow\" width=\"334\" height=\"247\" viewBox=\"0 0 334 247\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <mask id=\"path-1-inside-1\" fill=\"white\">\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\"/>\n        </mask>\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\" fill=\"white\"/>\n        <path d=\"M263 0L263.939 -0.342761L262.02 0.198419L263 0ZM275.801 33.6224L274.869 33.9859L274.869 33.9859L275.801 33.6224ZM266 94L265.03 93.7551L265.03 93.7551L266 94ZM235.795 152.939L235.169 153.719L236.009 154.393L236.619 153.505L235.795 152.939ZM160.9 155.853L160.252 156.614L160.944 157.204L161.597 156.571L160.9 155.853ZM83.6778 159.087L83.7301 160.085L84.1272 160.064L84.4017 159.777L83.6778 159.087ZM82.9191 159.131L82.3719 159.968L82.6508 160.15L82.9834 160.129L82.9191 159.131ZM55.0809 232.869L55.6281 232.032L55.3492 231.85L55.0166 231.871L55.0809 232.869ZM111.599 236.862L112.176 236.045L111.71 235.716L111.189 235.95L111.599 236.862ZM181.5 234.485L182.14 233.716L181.5 233.183L180.86 233.716L181.5 234.485ZM260.278 228.718L260.549 227.755L259.924 227.579L259.509 228.079L260.278 228.718ZM269.733 230.582L269.946 229.605L269.898 229.594L269.848 229.589L269.733 230.582ZM333.942 188.5L332.943 188.442L332.94 188.5L332.943 188.558L333.942 188.5ZM304.171 148.734L303.175 148.826L303.233 149.452L303.823 149.671L304.171 148.734ZM294.5 87.5L295.467 87.2461L295.467 87.2461L294.5 87.5ZM262.061 0.342761C266.659 12.9469 270.94 23.9174 274.869 33.9859L276.732 33.2588C272.803 23.1894 268.53 12.2379 263.939 -0.342761L262.061 0.342761ZM266.97 94.2449C271.463 76.4505 270.696 52.8033 268.832 33.6911C267.898 24.1176 266.686 15.6493 265.707 9.574C265.218 6.53601 264.786 4.09548 264.477 2.41328C264.323 1.57216 264.199 0.920563 264.113 0.478594C264.07 0.257607 264.037 0.0890213 264.015 -0.0246501C264.004 -0.081486 263.995 -0.124594 263.989 -0.15366C263.986 -0.168193 263.984 -0.179216 263.982 -0.186689C263.982 -0.190425 263.981 -0.193274 263.981 -0.195231C263.981 -0.196209 263.98 -0.197006 263.98 -0.197496C263.98 -0.198069 263.98 -0.198419 263 0C262.02 0.198419 262.02 0.198518 262.02 0.19884C262.02 0.199246 262.02 0.199791 262.02 0.200601C262.021 0.202222 262.021 0.204734 262.022 0.208132C262.023 0.214928 262.025 0.22527 262.028 0.239119C262.034 0.266816 262.042 0.308538 262.053 0.363973C262.075 0.474842 262.107 0.640556 262.15 0.858604C262.234 1.2947 262.357 1.94011 262.51 2.77475C262.817 4.44408 263.246 6.87008 263.733 9.89213C264.707 15.9369 265.913 24.3627 266.841 33.8852C268.702 52.9652 269.434 76.3179 265.03 93.7551L266.97 94.2449ZM236.619 153.505C247.952 136.991 262.031 113.801 266.97 94.2449L265.03 93.7551C260.187 112.934 246.297 135.868 234.97 152.373L236.619 153.505ZM200 142C213.734 142 226.15 146.487 235.169 153.719L236.42 152.158C227.025 144.625 214.161 140 200 140V142ZM161.597 156.571C170.751 147.687 184.537 142 200 142V140C184.061 140 169.761 145.86 160.204 155.136L161.597 156.571ZM124 144C138.293 144 151.157 148.859 160.252 156.614L161.549 155.092C152.069 147.008 138.736 142 124 142V144ZM84.4017 159.777C93.5252 150.205 107.847 144 124 144V142C107.352 142 92.4895 148.393 82.954 158.397L84.4017 159.777ZM82.9834 160.129C83.2317 160.113 83.4806 160.098 83.7301 160.085L83.6256 158.088C83.3682 158.101 83.1112 158.116 82.8548 158.133L82.9834 160.129ZM51 151C62.8947 151 73.8031 154.366 82.3719 159.968L83.4663 158.294C74.5591 152.471 63.2675 149 51 149V151ZM1 191.5C1 169.315 23.1833 151 51 151V149C22.4837 149 -1 167.845 -1 191.5H1ZM51 232C23.1833 232 1 213.685 1 191.5H-1C-1 215.155 22.4837 234 51 234V232ZM55.0166 231.871C53.6918 231.957 52.3522 232 51 232V234C52.3951 234 53.7775 233.955 55.1452 233.867L55.0166 231.871ZM87 241C75.1053 241 64.1968 237.634 55.6281 232.032L54.5337 233.706C63.4409 239.529 74.7325 243 87 243V241ZM111.189 235.95C104.026 239.166 95.7811 241 87 241V243C96.0584 243 104.583 241.108 112.009 237.775L111.189 235.95ZM145 246C132.422 246 120.947 242.236 112.176 236.045L111.022 237.679C120.147 244.12 132.028 248 145 248V246ZM180.86 233.716C171.789 241.279 159.089 246 145 246V248C159.526 248 172.688 243.134 182.14 235.253L180.86 233.716ZM218 246C203.911 246 191.211 241.279 182.14 233.716L180.86 235.253C190.312 243.134 203.474 248 218 248V246ZM259.509 228.079C250.553 238.856 235.333 246 218 246V248C235.859 248 251.669 240.641 261.047 229.357L259.509 228.079ZM269.848 229.589C266.639 229.216 263.53 228.597 260.549 227.755L260.006 229.68C263.09 230.551 266.304 231.191 269.618 231.575L269.848 229.589ZM283 231C278.482 231 274.106 230.514 269.946 229.605L269.519 231.559C273.82 232.499 278.339 233 283 233V231ZM333 190.5C333 212.685 310.817 231 283 231V233C311.516 233 335 214.155 335 190.5H333ZM332.943 188.558C332.981 189.202 333 189.849 333 190.5H335C335 189.81 334.98 189.124 334.94 188.442L332.943 188.558ZM333 186.5C333 187.151 332.981 187.798 332.943 188.442L334.94 188.558C334.98 187.876 335 187.19 335 186.5H333ZM303.823 149.671C321.143 156.111 333 170.253 333 186.5H335C335 169.2 322.398 154.443 304.52 147.796L303.823 149.671ZM293.533 87.7539C298.292 105.889 300.985 125.089 303.175 148.826L305.167 148.642C302.972 124.861 300.268 105.536 295.467 87.2461L293.533 87.7539ZM274.869 33.9859C282.488 53.5107 288.774 69.6224 293.533 87.7539L295.467 87.2461C290.674 68.9847 284.345 52.7667 276.732 33.2588L274.869 33.9859Z\" fill=\"#202020\" mask=\"url(#path-1-inside-1)\"/>\n      </svg>\n    </div>\n  </div>\n\n  <div *ngSwitchCase=\"'dyk-seconds-year'\">\n    <svg id=\"shadow\" width=\"252\" height=\"255\" viewBox=\"0 0 252 255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n      <g filter=\"url(#filter0_d)\">\n      <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"128.213\" cy=\"53.2132\" r=\"15\" transform=\"rotate(45 128.213 53.2132)\" fill=\"black\"/>\n      <circle cx=\"128\" cy=\"46\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n      <g filter=\"url(#filter1_d)\">\n      <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n      <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n      <path d=\"M131 126.5C126.932 129.806 105.53 128.834 100.304 122.405C95.0789 115.977 96.9325 96.3062 101 93C105.068 89.6937 109.809 104.004 115.034 110.432C120.259 116.861 135.068 123.194 131 126.5Z\" fill=\"black\"/>\n      <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"86\" y=\"90\" width=\"47\" height=\"50\">\n      <path d=\"M131 126.5C126.932 129.806 105.53 128.834 100.304 122.405C95.0789 115.977 96.9325 96.3062 101 93C105.068 89.6937 109.809 104.004 115.034 110.432C120.259 116.861 135.068 123.194 131 126.5Z\" fill=\"black\"/>\n      </mask>\n      <g mask=\"url(#mask0)\">\n      <rect x=\"113.984\" y=\"106.131\" width=\"8\" height=\"7.59286\" rx=\"2\" transform=\"rotate(50.8943 113.984 106.131)\" fill=\"white\"/>\n      <rect x=\"121.48\" y=\"111.636\" width=\"8\" height=\"9.93782\" rx=\"3\" transform=\"rotate(50.8943 121.48 111.636)\" fill=\"white\"/>\n      <rect x=\"109.151\" y=\"98.4614\" width=\"8\" height=\"8.67977\" rx=\"3\" transform=\"rotate(50.8943 109.151 98.4614)\" fill=\"white\"/>\n      </g>\n      <defs>\n      <filter id=\"filter0_d\" x=\"94\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n      <stop stop-color=\"#895E3B\"/>\n      <stop offset=\"1\" stop-color=\"#6B401D\"/>\n      </linearGradient>\n      </defs>\n    </svg>\n    <div id=\"speech-bubble\">\n      <p>There are over 31.5m seconds a year</p>\n      <svg id=\"shadow\" width=\"334\" height=\"247\" viewBox=\"0 0 334 247\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <mask id=\"path-1-inside-1\" fill=\"white\">\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\"/>\n        </mask>\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\" fill=\"white\"/>\n        <path d=\"M263 0L263.939 -0.342761L262.02 0.198419L263 0ZM275.801 33.6224L274.869 33.9859L274.869 33.9859L275.801 33.6224ZM266 94L265.03 93.7551L265.03 93.7551L266 94ZM235.795 152.939L235.169 153.719L236.009 154.393L236.619 153.505L235.795 152.939ZM160.9 155.853L160.252 156.614L160.944 157.204L161.597 156.571L160.9 155.853ZM83.6778 159.087L83.7301 160.085L84.1272 160.064L84.4017 159.777L83.6778 159.087ZM82.9191 159.131L82.3719 159.968L82.6508 160.15L82.9834 160.129L82.9191 159.131ZM55.0809 232.869L55.6281 232.032L55.3492 231.85L55.0166 231.871L55.0809 232.869ZM111.599 236.862L112.176 236.045L111.71 235.716L111.189 235.95L111.599 236.862ZM181.5 234.485L182.14 233.716L181.5 233.183L180.86 233.716L181.5 234.485ZM260.278 228.718L260.549 227.755L259.924 227.579L259.509 228.079L260.278 228.718ZM269.733 230.582L269.946 229.605L269.898 229.594L269.848 229.589L269.733 230.582ZM333.942 188.5L332.943 188.442L332.94 188.5L332.943 188.558L333.942 188.5ZM304.171 148.734L303.175 148.826L303.233 149.452L303.823 149.671L304.171 148.734ZM294.5 87.5L295.467 87.2461L295.467 87.2461L294.5 87.5ZM262.061 0.342761C266.659 12.9469 270.94 23.9174 274.869 33.9859L276.732 33.2588C272.803 23.1894 268.53 12.2379 263.939 -0.342761L262.061 0.342761ZM266.97 94.2449C271.463 76.4505 270.696 52.8033 268.832 33.6911C267.898 24.1176 266.686 15.6493 265.707 9.574C265.218 6.53601 264.786 4.09548 264.477 2.41328C264.323 1.57216 264.199 0.920563 264.113 0.478594C264.07 0.257607 264.037 0.0890213 264.015 -0.0246501C264.004 -0.081486 263.995 -0.124594 263.989 -0.15366C263.986 -0.168193 263.984 -0.179216 263.982 -0.186689C263.982 -0.190425 263.981 -0.193274 263.981 -0.195231C263.981 -0.196209 263.98 -0.197006 263.98 -0.197496C263.98 -0.198069 263.98 -0.198419 263 0C262.02 0.198419 262.02 0.198518 262.02 0.19884C262.02 0.199246 262.02 0.199791 262.02 0.200601C262.021 0.202222 262.021 0.204734 262.022 0.208132C262.023 0.214928 262.025 0.22527 262.028 0.239119C262.034 0.266816 262.042 0.308538 262.053 0.363973C262.075 0.474842 262.107 0.640556 262.15 0.858604C262.234 1.2947 262.357 1.94011 262.51 2.77475C262.817 4.44408 263.246 6.87008 263.733 9.89213C264.707 15.9369 265.913 24.3627 266.841 33.8852C268.702 52.9652 269.434 76.3179 265.03 93.7551L266.97 94.2449ZM236.619 153.505C247.952 136.991 262.031 113.801 266.97 94.2449L265.03 93.7551C260.187 112.934 246.297 135.868 234.97 152.373L236.619 153.505ZM200 142C213.734 142 226.15 146.487 235.169 153.719L236.42 152.158C227.025 144.625 214.161 140 200 140V142ZM161.597 156.571C170.751 147.687 184.537 142 200 142V140C184.061 140 169.761 145.86 160.204 155.136L161.597 156.571ZM124 144C138.293 144 151.157 148.859 160.252 156.614L161.549 155.092C152.069 147.008 138.736 142 124 142V144ZM84.4017 159.777C93.5252 150.205 107.847 144 124 144V142C107.352 142 92.4895 148.393 82.954 158.397L84.4017 159.777ZM82.9834 160.129C83.2317 160.113 83.4806 160.098 83.7301 160.085L83.6256 158.088C83.3682 158.101 83.1112 158.116 82.8548 158.133L82.9834 160.129ZM51 151C62.8947 151 73.8031 154.366 82.3719 159.968L83.4663 158.294C74.5591 152.471 63.2675 149 51 149V151ZM1 191.5C1 169.315 23.1833 151 51 151V149C22.4837 149 -1 167.845 -1 191.5H1ZM51 232C23.1833 232 1 213.685 1 191.5H-1C-1 215.155 22.4837 234 51 234V232ZM55.0166 231.871C53.6918 231.957 52.3522 232 51 232V234C52.3951 234 53.7775 233.955 55.1452 233.867L55.0166 231.871ZM87 241C75.1053 241 64.1968 237.634 55.6281 232.032L54.5337 233.706C63.4409 239.529 74.7325 243 87 243V241ZM111.189 235.95C104.026 239.166 95.7811 241 87 241V243C96.0584 243 104.583 241.108 112.009 237.775L111.189 235.95ZM145 246C132.422 246 120.947 242.236 112.176 236.045L111.022 237.679C120.147 244.12 132.028 248 145 248V246ZM180.86 233.716C171.789 241.279 159.089 246 145 246V248C159.526 248 172.688 243.134 182.14 235.253L180.86 233.716ZM218 246C203.911 246 191.211 241.279 182.14 233.716L180.86 235.253C190.312 243.134 203.474 248 218 248V246ZM259.509 228.079C250.553 238.856 235.333 246 218 246V248C235.859 248 251.669 240.641 261.047 229.357L259.509 228.079ZM269.848 229.589C266.639 229.216 263.53 228.597 260.549 227.755L260.006 229.68C263.09 230.551 266.304 231.191 269.618 231.575L269.848 229.589ZM283 231C278.482 231 274.106 230.514 269.946 229.605L269.519 231.559C273.82 232.499 278.339 233 283 233V231ZM333 190.5C333 212.685 310.817 231 283 231V233C311.516 233 335 214.155 335 190.5H333ZM332.943 188.558C332.981 189.202 333 189.849 333 190.5H335C335 189.81 334.98 189.124 334.94 188.442L332.943 188.558ZM333 186.5C333 187.151 332.981 187.798 332.943 188.442L334.94 188.558C334.98 187.876 335 187.19 335 186.5H333ZM303.823 149.671C321.143 156.111 333 170.253 333 186.5H335C335 169.2 322.398 154.443 304.52 147.796L303.823 149.671ZM293.533 87.7539C298.292 105.889 300.985 125.089 303.175 148.826L305.167 148.642C302.972 124.861 300.268 105.536 295.467 87.2461L293.533 87.7539ZM274.869 33.9859C282.488 53.5107 288.774 69.6224 293.533 87.7539L295.467 87.2461C290.674 68.9847 284.345 52.7667 276.732 33.2588L274.869 33.9859Z\" fill=\"#202020\" mask=\"url(#path-1-inside-1)\"/>\n      </svg>\n    </div>\n  </div>\n  \n  <div *ngSwitchCase=\"'relative'\">\n    <svg id=\"shadow\" width=\"252\" height=\"255\" viewBox=\"0 0 252 255\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n      <path d=\"M3.32173 2.5H226.225L248.839 242.41C248.049 242.73 246.987 243.147 245.679 243.628C242.565 244.772 238.07 246.275 232.576 247.697C221.57 250.546 206.644 253.046 190.821 251.743C175.022 250.442 158.388 245.357 143.813 233.088C129.24 220.821 116.52 201.199 108.848 170.46C102.944 146.802 92.2838 128.743 79.3969 111.732C73.0699 103.38 66.1887 95.2587 59.086 86.876L58.7411 86.469C51.5033 77.9266 44.0279 69.0894 36.5738 59.3503C21.6778 39.8882 13.125 24.8197 8.30721 14.6701C5.89822 9.59514 4.42245 5.74867 3.55422 3.19609C3.47127 2.95224 3.39387 2.72019 3.32173 2.5Z\" fill=\"url(#paint0_linear)\" stroke=\"black\" stroke-width=\"5\"/>\n      <g filter=\"url(#filter0_d)\">\n      <ellipse cx=\"136.891\" cy=\"43.8909\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 136.891 43.8909)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"148.213\" cy=\"32.2132\" r=\"15\" transform=\"rotate(45 148.213 32.2132)\" fill=\"black\"/>\n      <circle cx=\"148\" cy=\"25\" r=\"4.5\" fill=\"white\" stroke=\"black\"/>\n      <g filter=\"url(#filter1_d)\">\n      <ellipse cx=\"184.974\" cy=\"91.9741\" rx=\"21.5\" ry=\"33.5\" transform=\"rotate(45 184.974 91.9741)\" fill=\"white\"/>\n      </g>\n      <circle cx=\"175.238\" cy=\"102.976\" r=\"15\" transform=\"rotate(45 175.238 102.976)\" fill=\"black\"/>\n      <circle cx=\"174\" cy=\"97\" r=\"5\" fill=\"white\"/>\n      <mask id=\"mask0\" mask-type=\"alpha\" maskUnits=\"userSpaceOnUse\" x=\"90\" y=\"96\" width=\"38\" height=\"40\">\n      <path d=\"M115.741 133.111C109.287 138.304 110.797 126.966 104.699 119.386C98.6005 111.807 87.2023 110.855 93.6568 105.662C100.111 100.469 110.287 102.404 116.386 109.983C122.484 117.563 122.196 127.917 115.741 133.111Z\" fill=\"black\"/>\n      </mask>\n      <g mask=\"url(#mask0)\">\n      <rect x=\"116.216\" y=\"104.986\" width=\"8\" height=\"12\" rx=\"2\" transform=\"rotate(51.181 116.216 104.986)\" fill=\"white\"/>\n      <rect x=\"121.858\" y=\"111.998\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(51.181 121.858 111.998)\" fill=\"white\"/>\n      <rect x=\"110.574\" y=\"97.9741\" width=\"8\" height=\"12\" rx=\"3\" transform=\"rotate(51.181 110.574 97.9741)\" fill=\"white\"/>\n      </g>\n      <defs>\n      <filter id=\"filter0_d\" x=\"94\" y=\"5\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <filter id=\"filter1_d\" x=\"142.083\" y=\"53.0833\" width=\"85.7817\" height=\"85.7817\" filterUnits=\"userSpaceOnUse\" color-interpolation-filters=\"sRGB\">\n      <feFlood flood-opacity=\"0\" result=\"BackgroundImageFix\"/>\n      <feColorMatrix in=\"SourceAlpha\" type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0\"/>\n      <feOffset dy=\"4\"/>\n      <feGaussianBlur stdDeviation=\"2\"/>\n      <feColorMatrix type=\"matrix\" values=\"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0\"/>\n      <feBlend mode=\"normal\" in2=\"BackgroundImageFix\" result=\"effect1_dropShadow\"/>\n      <feBlend mode=\"normal\" in=\"SourceGraphic\" in2=\"effect1_dropShadow\" result=\"shape\"/>\n      </filter>\n      <linearGradient id=\"paint0_linear\" x1=\"249\" y1=\"-54.5\" x2=\"102.5\" y2=\"187.5\" gradientUnits=\"userSpaceOnUse\">\n      <stop stop-color=\"#895E3B\"/>\n      <stop offset=\"1\" stop-color=\"#6B401D\"/>\n      </linearGradient>\n      </defs>\n    </svg>\n    <div id=\"speech-bubble\">\n      <p>Time is relative</p>\n      <svg id=\"shadow\" width=\"334\" height=\"247\" viewBox=\"0 0 334 247\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <mask id=\"path-1-inside-1\" fill=\"white\">\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\"/>\n        </mask>\n        <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M275.801 33.6224C271.872 23.5534 267.595 12.5924 263 0C263 0 274.897 58.7684 266 94C261.109 113.368 247.125 136.429 235.795 152.939C226.587 145.556 213.947 141 200 141C184.299 141 170.256 146.773 160.9 155.853C151.613 147.934 138.515 143 124 143C107.6 143 93.0074 149.299 83.6778 159.087C83.4244 159.1 83.1715 159.115 82.9191 159.131C74.1811 153.418 63.0811 150 51 150C22.8335 150 0 168.58 0 191.5C0 214.42 22.8335 233 51 233C52.3737 233 53.7346 232.956 55.0809 232.869C63.8189 238.582 74.9189 242 87 242C95.9198 242 104.305 240.137 111.599 236.862C120.547 243.178 132.225 247 145 247C159.307 247 172.238 242.206 181.5 234.485C190.762 242.206 203.693 247 218 247C235.596 247 251.111 239.749 260.278 228.718C263.31 229.574 266.472 230.203 269.733 230.582C273.963 231.507 278.411 232 283 232C311.167 232 334 213.42 334 190.5C334 189.829 333.98 189.163 333.942 188.5C333.98 187.837 334 187.171 334 186.5C334 169.726 321.771 155.277 304.171 148.734C301.978 124.975 299.28 105.712 294.5 87.5C289.724 69.3035 283.416 53.1387 275.801 33.6224Z\" fill=\"white\"/>\n        <path d=\"M263 0L263.939 -0.342761L262.02 0.198419L263 0ZM275.801 33.6224L274.869 33.9859L274.869 33.9859L275.801 33.6224ZM266 94L265.03 93.7551L265.03 93.7551L266 94ZM235.795 152.939L235.169 153.719L236.009 154.393L236.619 153.505L235.795 152.939ZM160.9 155.853L160.252 156.614L160.944 157.204L161.597 156.571L160.9 155.853ZM83.6778 159.087L83.7301 160.085L84.1272 160.064L84.4017 159.777L83.6778 159.087ZM82.9191 159.131L82.3719 159.968L82.6508 160.15L82.9834 160.129L82.9191 159.131ZM55.0809 232.869L55.6281 232.032L55.3492 231.85L55.0166 231.871L55.0809 232.869ZM111.599 236.862L112.176 236.045L111.71 235.716L111.189 235.95L111.599 236.862ZM181.5 234.485L182.14 233.716L181.5 233.183L180.86 233.716L181.5 234.485ZM260.278 228.718L260.549 227.755L259.924 227.579L259.509 228.079L260.278 228.718ZM269.733 230.582L269.946 229.605L269.898 229.594L269.848 229.589L269.733 230.582ZM333.942 188.5L332.943 188.442L332.94 188.5L332.943 188.558L333.942 188.5ZM304.171 148.734L303.175 148.826L303.233 149.452L303.823 149.671L304.171 148.734ZM294.5 87.5L295.467 87.2461L295.467 87.2461L294.5 87.5ZM262.061 0.342761C266.659 12.9469 270.94 23.9174 274.869 33.9859L276.732 33.2588C272.803 23.1894 268.53 12.2379 263.939 -0.342761L262.061 0.342761ZM266.97 94.2449C271.463 76.4505 270.696 52.8033 268.832 33.6911C267.898 24.1176 266.686 15.6493 265.707 9.574C265.218 6.53601 264.786 4.09548 264.477 2.41328C264.323 1.57216 264.199 0.920563 264.113 0.478594C264.07 0.257607 264.037 0.0890213 264.015 -0.0246501C264.004 -0.081486 263.995 -0.124594 263.989 -0.15366C263.986 -0.168193 263.984 -0.179216 263.982 -0.186689C263.982 -0.190425 263.981 -0.193274 263.981 -0.195231C263.981 -0.196209 263.98 -0.197006 263.98 -0.197496C263.98 -0.198069 263.98 -0.198419 263 0C262.02 0.198419 262.02 0.198518 262.02 0.19884C262.02 0.199246 262.02 0.199791 262.02 0.200601C262.021 0.202222 262.021 0.204734 262.022 0.208132C262.023 0.214928 262.025 0.22527 262.028 0.239119C262.034 0.266816 262.042 0.308538 262.053 0.363973C262.075 0.474842 262.107 0.640556 262.15 0.858604C262.234 1.2947 262.357 1.94011 262.51 2.77475C262.817 4.44408 263.246 6.87008 263.733 9.89213C264.707 15.9369 265.913 24.3627 266.841 33.8852C268.702 52.9652 269.434 76.3179 265.03 93.7551L266.97 94.2449ZM236.619 153.505C247.952 136.991 262.031 113.801 266.97 94.2449L265.03 93.7551C260.187 112.934 246.297 135.868 234.97 152.373L236.619 153.505ZM200 142C213.734 142 226.15 146.487 235.169 153.719L236.42 152.158C227.025 144.625 214.161 140 200 140V142ZM161.597 156.571C170.751 147.687 184.537 142 200 142V140C184.061 140 169.761 145.86 160.204 155.136L161.597 156.571ZM124 144C138.293 144 151.157 148.859 160.252 156.614L161.549 155.092C152.069 147.008 138.736 142 124 142V144ZM84.4017 159.777C93.5252 150.205 107.847 144 124 144V142C107.352 142 92.4895 148.393 82.954 158.397L84.4017 159.777ZM82.9834 160.129C83.2317 160.113 83.4806 160.098 83.7301 160.085L83.6256 158.088C83.3682 158.101 83.1112 158.116 82.8548 158.133L82.9834 160.129ZM51 151C62.8947 151 73.8031 154.366 82.3719 159.968L83.4663 158.294C74.5591 152.471 63.2675 149 51 149V151ZM1 191.5C1 169.315 23.1833 151 51 151V149C22.4837 149 -1 167.845 -1 191.5H1ZM51 232C23.1833 232 1 213.685 1 191.5H-1C-1 215.155 22.4837 234 51 234V232ZM55.0166 231.871C53.6918 231.957 52.3522 232 51 232V234C52.3951 234 53.7775 233.955 55.1452 233.867L55.0166 231.871ZM87 241C75.1053 241 64.1968 237.634 55.6281 232.032L54.5337 233.706C63.4409 239.529 74.7325 243 87 243V241ZM111.189 235.95C104.026 239.166 95.7811 241 87 241V243C96.0584 243 104.583 241.108 112.009 237.775L111.189 235.95ZM145 246C132.422 246 120.947 242.236 112.176 236.045L111.022 237.679C120.147 244.12 132.028 248 145 248V246ZM180.86 233.716C171.789 241.279 159.089 246 145 246V248C159.526 248 172.688 243.134 182.14 235.253L180.86 233.716ZM218 246C203.911 246 191.211 241.279 182.14 233.716L180.86 235.253C190.312 243.134 203.474 248 218 248V246ZM259.509 228.079C250.553 238.856 235.333 246 218 246V248C235.859 248 251.669 240.641 261.047 229.357L259.509 228.079ZM269.848 229.589C266.639 229.216 263.53 228.597 260.549 227.755L260.006 229.68C263.09 230.551 266.304 231.191 269.618 231.575L269.848 229.589ZM283 231C278.482 231 274.106 230.514 269.946 229.605L269.519 231.559C273.82 232.499 278.339 233 283 233V231ZM333 190.5C333 212.685 310.817 231 283 231V233C311.516 233 335 214.155 335 190.5H333ZM332.943 188.558C332.981 189.202 333 189.849 333 190.5H335C335 189.81 334.98 189.124 334.94 188.442L332.943 188.558ZM333 186.5C333 187.151 332.981 187.798 332.943 188.442L334.94 188.558C334.98 187.876 335 187.19 335 186.5H333ZM303.823 149.671C321.143 156.111 333 170.253 333 186.5H335C335 169.2 322.398 154.443 304.52 147.796L303.823 149.671ZM293.533 87.7539C298.292 105.889 300.985 125.089 303.175 148.826L305.167 148.642C302.972 124.861 300.268 105.536 295.467 87.2461L293.533 87.7539ZM274.869 33.9859C282.488 53.5107 288.774 69.6224 293.533 87.7539L295.467 87.2461C290.674 68.9847 284.345 52.7667 276.732 33.2588L274.869 33.9859Z\" fill=\"#202020\" mask=\"url(#path-1-inside-1)\"/>\n      </svg>\n    </div>\n  </div>\n\n</div>\n\n\n  \n";
      /***/
    },

    /***/
    "./src/app/home/home-routing.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/home/home-routing.module.ts ***!
      \*********************************************/

    /*! exports provided: HomePageRoutingModule */

    /***/
    function srcAppHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
        return HomePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");

      var routes = [{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
      }, {
        path: 'profile',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | profile-profile-module */
          "profile-profile-module").then(__webpack_require__.bind(null,
          /*! ./profile/profile.module */
          "./src/app/home/profile/profile.module.ts")).then(function (m) {
            return m.ProfilePageModule;
          });
        }
      }, {
        path: 'stop',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | stop-stop-module */
          [__webpack_require__.e("common"), __webpack_require__.e("stop-stop-module")]).then(__webpack_require__.bind(null,
          /*! ./stop/stop.module */
          "./src/app/home/stop/stop.module.ts")).then(function (m) {
            return m.StopPageModule;
          });
        }
      }, {
        path: 'settings',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | settings-settings-module */
          [__webpack_require__.e("common"), __webpack_require__.e("settings-settings-module")]).then(__webpack_require__.bind(null,
          /*! ./settings/settings.module */
          "./src/app/home/settings/settings.module.ts")).then(function (m) {
            return m.SettingsPageModule;
          });
        }
      }, {
        path: 'statistics',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | statistics-statistics-module */
          "statistics-statistics-module").then(__webpack_require__.bind(null,
          /*! ./statistics/statistics.module */
          "./src/app/home/statistics/statistics.module.ts")).then(function (m) {
            return m.StatisticsPageModule;
          });
        }
      }];

      var HomePageRoutingModule = function HomePageRoutingModule() {
        _classCallCheck(this, HomePageRoutingModule);
      };

      HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HomePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/home/home.module.ts":
    /*!*************************************!*\
      !*** ./src/app/home/home.module.ts ***!
      \*************************************/

    /*! exports provided: HomePageModule */

    /***/
    function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
        return HomePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");
      /* harmony import */


      var _menu_menu_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./menu/menu.component */
      "./src/app/home/menu/menu.component.ts");
      /* harmony import */


      var _home_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./home-routing.module */
      "./src/app/home/home-routing.module.ts");
      /* harmony import */


      var _poobert_poobert_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./poobert/poobert.component */
      "./src/app/home/poobert/poobert.component.ts");

      var HomePageModule = function HomePageModule() {
        _classCallCheck(this, HomePageModule);
      };

      HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_7__["HomePageRoutingModule"]],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"], _menu_menu_component__WEBPACK_IMPORTED_MODULE_6__["Menu"], _poobert_poobert_component__WEBPACK_IMPORTED_MODULE_8__["PoobertComponent"]]
      })], HomePageModule);
      /***/
    },

    /***/
    "./src/app/home/home.page.scss":
    /*!*************************************!*\
      !*** ./src/app/home/home.page.scss ***!
      \*************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "app-poobert {\n  position: absolute;\n  width: 251.5px;\n  height: 254.6px;\n  right: -30px;\n  top: -5px;\n  z-index: 9;\n}\n\n#title {\n  color: var(--ion-color-secondary);\n  font-size: 68px;\n  line-height: 68px;\n  width: 211px;\n  margin: 58px 0px 0px 24px;\n  text-align: left;\n  transform: rotate(-13deg);\n  text-shadow: 0px 5px 5px rgba(0, 0, 0, 0.4);\n}\n\n#number-wrapper {\n  width: 95vw;\n  color: var(--ion-color-secondary);\n  margin: 148px auto 0px auto;\n  display: grid;\n}\n\n#inside-number-wrapper {\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n  margin: 0px auto 0px auto;\n}\n\n.timer {\n  font-size: 110px;\n  text-align: center;\n  margin: 0px;\n  text-shadow: 0px 5px 5px rgba(0, 0, 0, 0.4);\n  max-width: 100vw;\n}\n\n.timer-long {\n  height: 100px;\n  font-size: 75px;\n  text-shadow: 0px 5px 5px rgba(0, 0, 0, 0.4);\n  max-width: 100vw;\n}\n\n#money-counter {\n  font-size: 64px;\n  height: 64px;\n  line-height: 64px;\n  text-align: right;\n  margin: 0px;\n  text-shadow: 0px 5px 5px rgba(0, 0, 0, 0.4);\n}\n\n#watermark {\n  margin-left: 8px;\n  margin-top: -43px;\n  width: 211px;\n  font-size: 48px;\n  line-height: 48px;\n  opacity: 0.15;\n  transform: rotate(-13deg);\n  color: var(--ion-color-secondary);\n  text-align: center;\n}\n\n#watermark span {\n  color: var(--ion-color-dark);\n}\n\n#btn-wrapper {\n  width: 100vw;\n  display: flex;\n  justify-content: space-evenly;\n  align-items: center;\n  margin-bottom: 16px;\n  background: var(--ion-color-background);\n}\n\n#btn-wrapper ion-button {\n  max-width: 45vw;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUFDRjs7QUFFQTtFQUNFLGlDQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLDJDQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0VBQ0EsaUNBQUE7RUFDQSwyQkFBQTtFQUNBLGFBQUE7QUFDRjs7QUFFQTtFQUNFLDBCQUFBO0VBQUEsdUJBQUE7RUFBQSxrQkFBQTtFQUNBLHlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLDJDQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxlQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLDJDQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLGlDQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFDRTtFQUNFLDRCQUFBO0FBQ0o7O0FBR0E7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLHVDQUFBO0FBQUY7O0FBRUU7RUFDRSxlQUFBO0FBQUoiLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiYXBwLXBvb2JlcnQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAyNTEuNXB4O1xuICBoZWlnaHQ6IDI1NC42cHg7XG4gIHJpZ2h0OiAtMzBweDtcbiAgdG9wOiAtNXB4O1xuICB6LWluZGV4OiA5O1xufVxuXG4jdGl0bGUge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XG4gIGZvbnQtc2l6ZTogNjhweDtcbiAgbGluZS1oZWlnaHQ6IDY4cHg7XG4gIHdpZHRoOiAyMTFweDtcbiAgbWFyZ2luOiA1OHB4IDBweCAwcHggMjRweDtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTEzZGVnKTtcbiAgdGV4dC1zaGFkb3c6IDBweCA1cHggNXB4IHJnYmEoMCwwLDAsMC40KTtcbn1cblxuI251bWJlci13cmFwcGVyIHtcbiAgd2lkdGg6IDk1dnc7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcbiAgbWFyZ2luOjE0OHB4IGF1dG8gMHB4IGF1dG87XG4gIGRpc3BsYXk6IGdyaWQ7XG59XG5cbiNpbnNpZGUtbnVtYmVyLXdyYXBwZXIge1xuICB3aWR0aDogZml0LWNvbnRlbnQ7XG4gIG1hcmdpbjogMHB4IGF1dG8gMHB4IGF1dG87XG59XG5cbi50aW1lciB7XG4gIGZvbnQtc2l6ZTogMTEwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiAwcHg7XG4gIHRleHQtc2hhZG93OiAwcHggNXB4IDVweCByZ2JhKDAsMCwwLDAuNCk7XG4gIG1heC13aWR0aDogMTAwdnc7XG59XG5cbi50aW1lci1sb25nIHtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgZm9udC1zaXplOiA3NXB4O1xuICB0ZXh0LXNoYWRvdzogMHB4IDVweCA1cHggcmdiYSgwLDAsMCwwLjQpO1xuICBtYXgtd2lkdGg6IDEwMHZ3O1xufVxuXG4jbW9uZXktY291bnRlciB7XG4gIGZvbnQtc2l6ZTogNjRweDtcbiAgaGVpZ2h0OiA2NHB4O1xuICBsaW5lLWhlaWdodDogNjRweDtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIG1hcmdpbjogMHB4O1xuICB0ZXh0LXNoYWRvdzogMHB4IDVweCA1cHggcmdiYSgwLDAsMCwwLjQpO1xufVxuXG4jd2F0ZXJtYXJrIHtcbiAgbWFyZ2luLWxlZnQ6IDhweDtcbiAgbWFyZ2luLXRvcDogLTQzcHg7XG4gIHdpZHRoOiAyMTFweDtcbiAgZm9udC1zaXplOiA0OHB4O1xuICBsaW5lLWhlaWdodDogNDhweDtcbiAgb3BhY2l0eTogMC4xNTtcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTEzZGVnKTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgc3BhbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgfVxufVxuXG4jYnRuLXdyYXBwZXIge1xuICB3aWR0aDogMTAwdnc7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmFja2dyb3VuZCk7XG5cbiAgJiBpb24tYnV0dG9uIHtcbiAgICBtYXgtd2lkdGg6IDQ1dnc7XG4gIH1cbn1cblxuIl19 */";
      /***/
    },

    /***/
    "./src/app/home/home.page.ts":
    /*!***********************************!*\
      !*** ./src/app/home/home.page.ts ***!
      \***********************************/

    /*! exports provided: HomePage */

    /***/
    function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePage", function () {
        return HomePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs */
      "./node_modules/rxjs/_esm2015/index.js");
      /* harmony import */


      var _services_data_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../services/data-service.service */
      "./src/app/services/data-service.service.ts");
      /* harmony import */


      var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! moment */
      "./node_modules/moment/moment.js");
      /* harmony import */


      var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
      /* harmony import */


      var _services_item_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../services/item-storage.service */
      "./src/app/services/item-storage.service.ts");
      /* harmony import */


      var _services_user_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../services/user-storage.service */
      "./src/app/services/user-storage.service.ts");
      /* harmony import */


      var _services_environment_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../services/environment-storage.service */
      "./src/app/services/environment-storage.service.ts");
      /* harmony import */


      var _ionic_native_admob_free_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @ionic-native/admob-free/ngx */
      "./node_modules/@ionic-native/admob-free/__ivy_ngcc__/ngx/index.js");

      var HomePage = /*#__PURE__*/function () {
        function HomePage(router, dataService, itemStorageService, userStorageService, environmentStorageService, admobFree) {
          _classCallCheck(this, HomePage);

          this.router = router;
          this.dataService = dataService;
          this.itemStorageService = itemStorageService;
          this.userStorageService = userStorageService;
          this.environmentStorageService = environmentStorageService;
          this.admobFree = admobFree;
          this.menuClick = false;
          this.numbers = Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["timer"])(0, 1000);
          this.formatedTime = '00:00';
          this.timerRunning = false;
          this.showBannerAd();
        }

        _createClass(HomePage, [{
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            this.getData();
          }
        }, {
          key: "showBannerAd",
          value: function showBannerAd() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var bannerConfig, result;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      bannerConfig = {
                        id: 'ca-app-pub-5355321711329831~7856448335',
                        isTesting: true,
                        autoShow: true
                      };
                      this.admobFree.banner.config(bannerConfig);

                      try {
                        result = this.admobFree.banner.prepare();
                        console.log(result);
                      } catch (error) {
                        console.error(error);
                      }

                    case 3:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "getData",
          value: function getData() {
            if (this.dataService.user) {
              this.environment = this.dataService.environment;
              console.log('environment in home', this.environment);
            } else {
              this.router.navigate(['/initial-setup']);
            }
          }
        }, {
          key: "setPaid",
          value: function setPaid() {
            if (this.dataService.environment.currency) {
              this.paid = this.dataService.environment.currency.slice(0, 1) + 0;
            }
          }
        }, {
          key: "openMenu",
          value: function openMenu() {
            var _this = this;

            this.menuClick = true;
            setTimeout(function () {
              _this.menuClick = false;
            }, 500);
          }
        }, {
          key: "handleTimer",
          value: function handleTimer() {
            var _this2 = this;

            if (this.timerRunning === false) {
              this.timerRunning = true;
              this.dataService.startTime = moment__WEBPACK_IMPORTED_MODULE_5__["now"]();
              this.intervalFn = setInterval(function () {
                _this2.unformatedTime = ((moment__WEBPACK_IMPORTED_MODULE_5__["now"]() - _this2.dataService.startTime) / 1000).toFixed(0);
                _this2.dataService.currentTime = _this2.unformatedTime;

                if (_this2.unformatedTime < 3600) {
                  _this2.timerElement.nativeElement.classList.remove('timer-long');

                  _this2.formatedTime = new Date(_this2.unformatedTime * 1000).toISOString().substr(14, 5);
                } else {
                  _this2.timerElement.nativeElement.classList.add('timer-long');

                  _this2.formatedTime = new Date(_this2.unformatedTime * 1000).toISOString().substr(11, 8);
                }

                if (_this2.dataService.environment.hourlyRate) {
                  _this2.calculateMoney(_this2.unformatedTime);
                }
              }, 1000);
            } else {
              this.timerRunning = false;
              this.dataService.currentTime = undefined;
              clearInterval(this.intervalFn);
              this.dataService.stopTimeRaw = parseFloat(this.unformatedTime);
              this.dataService.stopTime = this.formatedTime;
              this.router.navigate(['/home/stop']);
              this.formatedTime = '00:00';
              this.setPaid();
            }
          }
        }, {
          key: "calculateMoney",
          value: function calculateMoney(time) {
            var hourlyRate = this.dataService.environment.hourlyRate;

            if (time) {
              var paidNumber = hourlyRate / 3600 * time;

              if (paidNumber < .01) {
                var paid = paidNumber.toFixed(3);
                this.formatMoney(paid);
              } else {
                var _paid = paidNumber.toFixed(2);

                this.formatMoney(_paid);
              }
            }
          }
        }, {
          key: "formatMoney",
          value: function formatMoney(paid) {
            var currency = this.dataService.environment.currency;
            this.paid = "".concat(currency.slice(0, 1)).concat(paid);
          }
        }, {
          key: "data",
          set: function set(value) {
            this.dataService.stopTime = value;
          }
        }]);

        return HomePage;
      }();

      HomePage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _services_data_service_service__WEBPACK_IMPORTED_MODULE_4__["DataServiceService"]
        }, {
          type: _services_item_storage_service__WEBPACK_IMPORTED_MODULE_6__["ItemStorageService"]
        }, {
          type: _services_user_storage_service__WEBPACK_IMPORTED_MODULE_7__["UserStorageService"]
        }, {
          type: _services_environment_storage_service__WEBPACK_IMPORTED_MODULE_8__["EnvironmentStorageService"]
        }, {
          type: _ionic_native_admob_free_ngx__WEBPACK_IMPORTED_MODULE_9__["AdMobFree"]
        }];
      };

      HomePage.propDecorators = {
        timerElement: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['timer']
        }],
        paidElement: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['paid']
        }]
      };
      HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home.page.scss */
        "./src/app/home/home.page.scss"))["default"]]
      })], HomePage);
      /***/
    },

    /***/
    "./src/app/home/menu/menu.component.scss":
    /*!***********************************************!*\
      !*** ./src/app/home/menu/menu.component.scss ***!
      \***********************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomeMenuMenuComponentScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "#menu-title {\n  background: var(--ion-color-background);\n  font-size: 48px;\n  color: var(--ion-color-secondary);\n  padding: 32px 0px 32px 24px;\n  margin: 0px;\n}\n\n#main-menu {\n  --background: var(--ion-color-background);\n  pointer-events: auto;\n}\n\n#menu-list {\n  width: 100%;\n  padding: 0px;\n  background: var(--ion-color-background);\n}\n\n#menu-list-bottom {\n  position: absolute;\n  width: 100%;\n  bottom: 32px;\n  padding: 0px;\n}\n\n.menu-item {\n  --background: var(--ion-color-background);\n  font-size: 32px;\n  color: var(--ion-color-dark);\n  border: none;\n}\n\n.menu-item-bottom {\n  font-size: 24px;\n}\n\n.top-menu-item {\n  margin-bottom: 10px;\n}\n\n.chevron {\n  margin-right: 0px;\n}\n\n#watermark {\n  margin-left: 32px;\n  margin-top: 100px;\n  width: 211px;\n  font-size: 48px;\n  line-height: 48px;\n  opacity: 0.15;\n  transform: rotate(-13deg);\n  color: var(--ion-color-secondary);\n  text-align: center;\n}\n\n#watermark span {\n  color: var(--ion-color-dark);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9tZW51L21lbnUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1Q0FBQTtFQUNBLGVBQUE7RUFDQSxpQ0FBQTtFQUNBLDJCQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUVBO0VBQ0UseUNBQUE7RUFDQSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSx1Q0FBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFDRjs7QUFFQTtFQUNFLHlDQUFBO0VBQ0EsZUFBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLGlDQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFDRTtFQUNFLDRCQUFBO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9ob21lL21lbnUvbWVudS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNtZW51LXRpdGxle1xyXG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1iYWNrZ3JvdW5kKTtcclxuICBmb250LXNpemU6IDQ4cHg7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gIHBhZGRpbmc6IDMycHggMHB4IDMycHggMjRweDtcclxuICBtYXJnaW46IDBweDtcclxufVxyXG5cclxuI21haW4tbWVudSB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmFja2dyb3VuZCk7XHJcbiAgcG9pbnRlci1ldmVudHM6IGF1dG87XHJcbn1cclxuXHJcbiNtZW51LWxpc3Qge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDBweDtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmFja2dyb3VuZCk7XHJcbn1cclxuXHJcbiNtZW51LWxpc3QtYm90dG9tIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm90dG9tOiAzMnB4O1xyXG4gIHBhZGRpbmc6IDBweDtcclxufVxyXG5cclxuLm1lbnUtaXRlbSB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmFja2dyb3VuZCk7XHJcbiAgZm9udC1zaXplOiAzMnB4O1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgYm9yZGVyOiBub25lO1xyXG59XHJcblxyXG4ubWVudS1pdGVtLWJvdHRvbSB7XHJcbiAgZm9udC1zaXplOiAyNHB4O1xyXG59XHJcblxyXG4udG9wLW1lbnUtaXRlbSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuLmNoZXZyb24ge1xyXG4gIG1hcmdpbi1yaWdodDogMHB4O1xyXG59XHJcblxyXG4jd2F0ZXJtYXJrIHtcclxuICBtYXJnaW4tbGVmdDogMzJweDtcclxuICBtYXJnaW4tdG9wOiAxMDBweDtcclxuICB3aWR0aDogMjExcHg7XHJcbiAgZm9udC1zaXplOiA0OHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA0OHB4O1xyXG4gIG9wYWNpdHk6IDAuMTU7XHJcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTEzZGVnKTtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxuICBzcGFuIHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgfVxyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/home/menu/menu.component.ts":
    /*!*********************************************!*\
      !*** ./src/app/home/menu/menu.component.ts ***!
      \*********************************************/

    /*! exports provided: Menu */

    /***/
    function srcAppHomeMenuMenuComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Menu", function () {
        return Menu;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var Menu = /*#__PURE__*/function () {
        function Menu(menu, router) {
          _classCallCheck(this, Menu);

          this.menu = menu;
          this.router = router;
        }

        _createClass(Menu, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ngOnChanges",
          value: function ngOnChanges(changes) {
            if (changes.menuClick && this.menuClick === true) {
              this.openFirst();
            }
          }
        }, {
          key: "openFirst",
          value: function openFirst() {
            this.menu.enable(true, 'first');
            this.menu.open('first');
          }
        }, {
          key: "navigateTo",
          value: function navigateTo(route) {
            this.menu.close('first');
            this.router.navigate([route]);
          }
        }, {
          key: "handleSignOut",
          value: function handleSignOut() {
            this.menu.close('first'); // Auth.signOut().then(() => {
            //   this.router.navigate(['/auth'])
            // })
          }
        }]);

        return Menu;
      }();

      Menu.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }];
      };

      Menu.propDecorators = {
        menuClick: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
        }],
        environment: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"]
        }]
      };
      Menu = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-menu',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./menu.component.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/menu/menu.component.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./menu.component.scss */
        "./src/app/home/menu/menu.component.scss"))["default"]]
      })], Menu);
      /***/
    },

    /***/
    "./src/app/home/poobert/poobert.component.scss":
    /*!*****************************************************!*\
      !*** ./src/app/home/poobert/poobert.component.scss ***!
      \*****************************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomePoobertPoobertComponentScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "#speech-bubble {\n  position: absolute;\n  right: 65px;\n  top: 129px;\n  z-index: 10;\n}\n#speech-bubble p {\n  position: absolute;\n  width: 100%;\n  z-index: 10;\n  text-align: center;\n  bottom: 30px;\n  font-size: 1.2rem;\n}\n#shadow {\n  filter: drop-shadow(0px 5px 5px rgba(0, 0, 0, 0.4));\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9wb29iZXJ0L3Bvb2JlcnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQUNGO0FBQ0U7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QUFDSjtBQUdBO0VBQ0UsbURBQUE7QUFBRiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvcG9vYmVydC9wb29iZXJ0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI3NwZWVjaC1idWJibGUge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogNjVweDtcclxuICB0b3A6IDEyOXB4O1xyXG4gIHotaW5kZXg6IDEwO1xyXG5cclxuICAmIHAge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB6LWluZGV4OiAxMDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvdHRvbTogMzBweDtcclxuICAgIGZvbnQtc2l6ZTogMS4ycmVtO1xyXG4gIH1cclxufVxyXG5cclxuI3NoYWRvdyB7XHJcbiAgZmlsdGVyOiBkcm9wLXNoYWRvdygwcHggNXB4IDVweCByZ2JhKDAsIDAsIDAsIDAuNCkpO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/home/poobert/poobert.component.ts":
    /*!***************************************************!*\
      !*** ./src/app/home/poobert/poobert.component.ts ***!
      \***************************************************/

    /*! exports provided: PoobertComponent */

    /***/
    function srcAppHomePoobertPoobertComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PoobertComponent", function () {
        return PoobertComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! src/app/services/environment-storage.service */
      "./src/app/services/environment-storage.service.ts");
      /* harmony import */


      var _services_data_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../services/data-service.service */
      "./src/app/services/data-service.service.ts");

      var PoobertComponent = /*#__PURE__*/function () {
        function PoobertComponent(dataService, environmentStorageService) {
          _classCallCheck(this, PoobertComponent);

          this.dataService = dataService;
          this.environmentStorageService = environmentStorageService; // poobertEmotion = 'dyk-seconds-year';

          this.poobertEmotion = 'normal';
          this.preTimerEmotions = ['waiting', 'tap-start', 'ima-poo', 'dyk-seconds-year', 'relative'];
          this.emotions = ['ima-poo', 'dyk-seconds-year', 'relative'];
          this.iteration = 0;
        }

        _createClass(PoobertComponent, [{
          key: "ngAfterViewInit",
          value: function ngAfterViewInit() {
            var _this3 = this;

            setInterval(function () {
              if (_this3.dataService.environment && !_this3.emotions.includes('longest') && _this3.dataService.environment.longestTime < _this3.dataService.currentTime) {
                _this3.emotions.push('longest');
              } else if (_this3.emotions.includes('longest') && _this3.dataService.currentTime === undefined) {
                _this3.emotions.splice(_this3.emotions.indexOf('longest'), 1);
              }

              if (_this3.dataService.environment && _this3.dataService.environment.streak > 0 && !_this3.emotions.includes('streak')) {
                _this3.emotions.push('streak');
              }

              ;

              if (_this3.dataService.environment && _this3.dataService.environment.name === 'Poo' && !_this3.emotions.includes('boss')) {
                _this3.emotions.push('boss');

                _this3.preTimerEmotions.push('boss');
              }

              if (_this3.dataService.startTime !== undefined) {
                if (_this3.iteration % 2 !== 0) {
                  var index = Math.floor(Math.random() * _this3.emotions.length);
                  _this3.poobertEmotion = _this3.emotions[index];
                  _this3.iteration += 1;
                } else {
                  _this3.poobertEmotion = 'normal';
                  _this3.iteration += 1;
                }
              } else {
                if (_this3.iteration % 2 !== 0) {
                  var _index = Math.floor(Math.random() * _this3.preTimerEmotions.length);

                  _this3.poobertEmotion = _this3.preTimerEmotions[_index];
                  _this3.iteration += 1;
                } else {
                  _this3.poobertEmotion = 'normal';
                  _this3.iteration += 1;
                }
              }
            }, 10000);
          }
        }]);

        return PoobertComponent;
      }();

      PoobertComponent.ctorParameters = function () {
        return [{
          type: _services_data_service_service__WEBPACK_IMPORTED_MODULE_3__["DataServiceService"]
        }, {
          type: src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_2__["EnvironmentStorageService"]
        }];
      };

      PoobertComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-poobert',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./poobert.component.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/poobert/poobert.component.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./poobert.component.scss */
        "./src/app/home/poobert/poobert.component.scss"))["default"]]
      })], PoobertComponent);
      /***/
    },

    /***/
    "./src/app/services/item-storage.service.ts":
    /*!**************************************************!*\
      !*** ./src/app/services/item-storage.service.ts ***!
      \**************************************************/

    /*! exports provided: ItemStorageService */

    /***/
    function srcAppServicesItemStorageServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ItemStorageService", function () {
        return ItemStorageService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");

      var ITEMS_KEY = 'items';

      var ItemStorageService = /*#__PURE__*/function () {
        function ItemStorageService(storage) {
          _classCallCheck(this, ItemStorageService);

          this.storage = storage;
        }

        _createClass(ItemStorageService, [{
          key: "addItem",
          value: function addItem(item) {
            var _this4 = this;

            return this.storage.get(ITEMS_KEY).then(function (items) {
              if (items) {
                items.push(item);
                return _this4.storage.set(ITEMS_KEY, items);
              } else {
                return _this4.storage.set(ITEMS_KEY, [item]);
              }
            });
          }
        }, {
          key: "getItems",
          value: function getItems() {
            return this.storage.get(ITEMS_KEY);
          }
        }, {
          key: "updateItem",
          value: function updateItem(item) {
            var _this5 = this;

            return this.storage.get(ITEMS_KEY).then(function (items) {
              if (!items || HTMLIonItemSlidingElement.length === 0) {
                return null;
              }

              var newItems = [];

              var _iterator = _createForOfIteratorHelper(items),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var p = _step.value;

                  if (p.id === item.id) {
                    newItems.push(item);
                  } else {
                    newItems.push(p);
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }

              return _this5.storage.set(ITEMS_KEY, newItems);
            });
          }
        }, {
          key: "deleteItem",
          value: function deleteItem(id) {
            var _this6 = this;

            return this.storage.get(ITEMS_KEY).then(function (items) {
              if (!items || items.length === 0) {
                return null;
              }

              var toKeep = [];

              var _iterator2 = _createForOfIteratorHelper(items),
                  _step2;

              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var p = _step2.value;

                  if (p.id !== id) {
                    toKeep.push(p);
                  }
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }

              return _this6.storage.set(ITEMS_KEY, toKeep);
            });
          }
        }, {
          key: "deleteEnvironmentItems",
          value: function deleteEnvironmentItems(environmentID) {
            var _this7 = this;

            this.storage.get(ITEMS_KEY).then(function (items) {
              var toKeep = [];

              var _iterator3 = _createForOfIteratorHelper(items),
                  _step3;

              try {
                for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                  var i = _step3.value;

                  if (i.environmentID !== environmentID) {
                    toKeep.push(i);
                  }
                }
              } catch (err) {
                _iterator3.e(err);
              } finally {
                _iterator3.f();
              }

              return _this7.storage.set(ITEMS_KEY, toKeep);
            });
          }
        }, {
          key: "clearItems",
          value: function clearItems() {
            this.storage.clear();
          }
        }]);

        return ItemStorageService;
      }();

      ItemStorageService.ctorParameters = function () {
        return [{
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]
        }];
      };

      ItemStorageService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ItemStorageService);
      /***/
    }
  }]);
})();
//# sourceMappingURL=home-home-module-es5.js.map