(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["timer-environment-environment-select-environment-select-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/timer-environment/environment-select/environment-select.page.html":
/*!*************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/timer-environment/environment-select/environment-select.page.html ***!
  \*************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <h1>Select Environment</h1>\n  <p id=\"change\">Change the timer</p>\n\n    <ion-item *ngFor=\"let environment of environments\" (click)=\"selectEnvironment(environment)\">\n      <ion-label\n      class=\"label\"\n      position=\"stacked\"\n      >{{environment.name}} Timer</ion-label>\n      <p *ngIf=\"environment.hourlyRate\"><span>Hourly Rate:</span> {{environment.hourlyRate}}</p>\n      <p *ngIf=\"environment.currency\"><span>Currency:</span> {{environment.currency}}</p>\n      <p *ngIf=\"environment.firstTimeDate\"><span>Timing Since:</span> {{calculateTimingSinceDate(environment.firstTimeDate)}}</p>\n      <ion-icon\n        *ngIf=\"environment.id !== 1\"\n        class=\"menu-icon\"\n        name=\"trash-outline\"\n        slot=\"end\"\n        size=\"large\"\n        (click)=\"handleTrashClick($event, environment)\"\n      ></ion-icon>\n    </ion-item>\n    \n</ion-content>\n\n<div id=\"btn-wrapper\">\n  <ion-button color=\"primary\" id=\"primary-btn\" (click)=\"addNewEnvironment()\">ADD NEW</ion-button>\n</div>\n\n\n\n");

/***/ }),

/***/ "./src/app/timer-environment/environment-select/environment-select-routing.module.ts":
/*!*******************************************************************************************!*\
  !*** ./src/app/timer-environment/environment-select/environment-select-routing.module.ts ***!
  \*******************************************************************************************/
/*! exports provided: EnvironmentSelectPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EnvironmentSelectPageRoutingModule", function() { return EnvironmentSelectPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _environment_select_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environment-select.page */ "./src/app/timer-environment/environment-select/environment-select.page.ts");




const routes = [
    {
        path: '',
        component: _environment_select_page__WEBPACK_IMPORTED_MODULE_3__["EnvironmentSelectPage"]
    }
];
let EnvironmentSelectPageRoutingModule = class EnvironmentSelectPageRoutingModule {
};
EnvironmentSelectPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EnvironmentSelectPageRoutingModule);



/***/ }),

/***/ "./src/app/timer-environment/environment-select/environment-select.module.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/timer-environment/environment-select/environment-select.module.ts ***!
  \***********************************************************************************/
/*! exports provided: EnvironmentSelectPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EnvironmentSelectPageModule", function() { return EnvironmentSelectPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _environment_select_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./environment-select-routing.module */ "./src/app/timer-environment/environment-select/environment-select-routing.module.ts");
/* harmony import */ var _environment_select_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./environment-select.page */ "./src/app/timer-environment/environment-select/environment-select.page.ts");







let EnvironmentSelectPageModule = class EnvironmentSelectPageModule {
};
EnvironmentSelectPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _environment_select_routing_module__WEBPACK_IMPORTED_MODULE_5__["EnvironmentSelectPageRoutingModule"]
        ],
        declarations: [_environment_select_page__WEBPACK_IMPORTED_MODULE_6__["EnvironmentSelectPage"]]
    })
], EnvironmentSelectPageModule);



/***/ }),

/***/ "./src/app/timer-environment/environment-select/environment-select.page.scss":
/*!***********************************************************************************!*\
  !*** ./src/app/timer-environment/environment-select/environment-select.page.scss ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("h1 {\n  font-size: 48px;\n  color: var(--ion-color-secondary);\n  margin: 32px auto 0px auto;\n  text-align: center;\n  line-height: 45px;\n}\n\n#change {\n  font-size: 18px;\n  color: var(--ion-color-dark);\n  margin: 0px auto 24px auto;\n  text-align: center;\n}\n\nion-item {\n  --background: var(--ion-color-primary-tint);\n  --border-color: var(--ion-color-secondary);\n  margin: 0px;\n}\n\nion-item p {\n  margin: 0;\n  color: var(--ion-color-dark);\n  font-size: 1.3rem;\n}\n\nion-item p span {\n  font-size: 1.1rem;\n}\n\nion-item ion-icon {\n  margin: auto;\n}\n\n.label {\n  font-size: 56px;\n  color: var(--ion-color-secondary);\n  margin-bottom: 8px;\n}\n\n#btn-wrapper {\n  margin-bottom: 16px;\n  width: 100%;\n  background: var(--ion-color-background);\n}\n\n#primary-btn {\n  display: block;\n  width: 90vw;\n  margin: 0 auto;\n  bottom: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGltZXItZW52aXJvbm1lbnQvZW52aXJvbm1lbnQtc2VsZWN0L2Vudmlyb25tZW50LXNlbGVjdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFBO0VBQ0EsaUNBQUE7RUFDQSwwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSw0QkFBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLDJDQUFBO0VBQ0EsMENBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBRUU7RUFDRSxTQUFBO0VBQ0EsNEJBQUE7RUFDQSxpQkFBQTtBQUFKOztBQUVJO0VBQ0UsaUJBQUE7QUFBTjs7QUFJRTtFQUNFLFlBQUE7QUFGSjs7QUFNQTtFQUNFLGVBQUE7RUFDQSxpQ0FBQTtFQUNBLGtCQUFBO0FBSEY7O0FBTUE7RUFDRSxtQkFBQTtFQUNBLFdBQUE7RUFDQSx1Q0FBQTtBQUhGOztBQU1BO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQUhGIiwiZmlsZSI6InNyYy9hcHAvdGltZXItZW52aXJvbm1lbnQvZW52aXJvbm1lbnQtc2VsZWN0L2Vudmlyb25tZW50LXNlbGVjdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoMXtcclxuICBmb250LXNpemU6IDQ4cHg7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gIG1hcmdpbjogMzJweCBhdXRvIDBweCBhdXRvO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBsaW5lLWhlaWdodDogNDVweDtcclxufVxyXG5cclxuI2NoYW5nZSB7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgbWFyZ2luOiAwcHggYXV0byAyNHB4IGF1dG87XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS10aW50KTtcclxuICAtLWJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZGFyeSk7XHJcbiAgbWFyZ2luOiAwcHg7XHJcblxyXG5cclxuICAmIHAge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgIGZvbnQtc2l6ZTogMS4zcmVtO1xyXG5cclxuICAgICYgc3BhbiB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMS4xcmVtOztcclxuICAgIH1cclxuICB9XHJcblxyXG4gICYgaW9uLWljb24ge1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gIH1cclxufVxyXG5cclxuLmxhYmVsIHtcclxuICBmb250LXNpemU6IDU2cHg7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gIG1hcmdpbi1ib3R0b206IDhweDtcclxufVxyXG5cclxuI2J0bi13cmFwcGVyIHtcclxuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1iYWNrZ3JvdW5kKTtcclxufVxyXG5cclxuI3ByaW1hcnktYnRuIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICB3aWR0aDogOTB2dztcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBib3R0b206IDMycHg7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/timer-environment/environment-select/environment-select.page.ts":
/*!*********************************************************************************!*\
  !*** ./src/app/timer-environment/environment-select/environment-select.page.ts ***!
  \*********************************************************************************/
/*! exports provided: EnvironmentSelectPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EnvironmentSelectPage", function() { return EnvironmentSelectPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var src_app_services_data_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/data-service.service */ "./src/app/services/data-service.service.ts");
/* harmony import */ var src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/environment-storage.service */ "./src/app/services/environment-storage.service.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_app_services_user_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/user-storage.service */ "./src/app/services/user-storage.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");








let EnvironmentSelectPage = class EnvironmentSelectPage {
    constructor(dataService, environmentStorageService, userStorageService, router, alertController) {
        this.dataService = dataService;
        this.environmentStorageService = environmentStorageService;
        this.userStorageService = userStorageService;
        this.router = router;
        this.alertController = alertController;
    }
    ionViewWillEnter() {
        this.environmentStorageService.listEnvironments().then((environments) => {
            this.environments = environments;
        });
        this.user = this.dataService.user;
    }
    calculateTimingSinceDate(date) {
        return moment__WEBPACK_IMPORTED_MODULE_5__(date).format('MMM \'YY');
    }
    selectEnvironment(environment) {
        this.userStorageService.getUser().then((user) => {
            this.user = user;
            this.user.activeEnvironmentID = environment.id;
            this.userStorageService.updateUser(this.user);
            this.dataService.environment = environment;
            console.log('environment in select', environment);
            this.router.navigate(['/home']);
        });
    }
    handleTrashClick(event, environment) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(event);
            event.stopPropagation();
            const alert = yield this.alertController.create({
                header: 'Delete!',
                message: 'This action will delete the environment and assosiated data. Are you sure you want to do this?  This action cannot be reversed.',
                cssClass: "alert-class",
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: "alert-cancel-button",
                        handler: (data) => {
                            console.log('Cancel');
                        }
                    }, {
                        text: 'Delete',
                        cssClass: "alert-confirm-button",
                        handler: () => {
                            console.log('Confirm Okay');
                            this.deleteEnvironment(environment);
                        }
                    }
                ]
            });
            alert.present();
        });
    }
    deleteEnvironment(environment) {
        this.environmentStorageService.deleteEnvironment(environment.id).then((data) => {
            this.environments = data;
            if (environment.id === this.user.activeEnvironmentID) {
                this.user.activeEnvironmentID = 1;
                this.userStorageService.updateUser(this.user);
            }
        });
    }
    addNewEnvironment() {
        this.router.navigate(['/environment-setup']);
    }
};
EnvironmentSelectPage.ctorParameters = () => [
    { type: src_app_services_data_service_service__WEBPACK_IMPORTED_MODULE_3__["DataServiceService"] },
    { type: src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_4__["EnvironmentStorageService"] },
    { type: src_app_services_user_storage_service__WEBPACK_IMPORTED_MODULE_6__["UserStorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"] }
];
EnvironmentSelectPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-environment-select',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./environment-select.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/timer-environment/environment-select/environment-select.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./environment-select.page.scss */ "./src/app/timer-environment/environment-select/environment-select.page.scss")).default]
    })
], EnvironmentSelectPage);



/***/ })

}]);
//# sourceMappingURL=timer-environment-environment-select-environment-select-module-es2015.js.map