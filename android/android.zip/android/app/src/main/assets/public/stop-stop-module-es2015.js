(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["stop-stop-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/stop/stop.page.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/stop/stop.page.html ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <p id=\"para-three\" *ngIf=\"firstTime\">First Time!</p>\n  <p id=\"para-one\">\n    That was a \n    <span *ngIf=\"showHours\">{{hours}} hour and </span>\n    <span *ngIf=\"showMinutes\">\n      <span>{{minutes}} minute </span>\n    </span>\n    <span>{{seconds}} second</span> \n    poo,\n  </p>\n  <p id=\"para-two\">meaning you were paid <span>{{paid}}</span> to poo</p>\n  <p *ngIf=\"!longestTime\" id=\"para-three\">Way to go!</p>\n  <p *ngIf=\"longestTime\" id=\"para-three\">That was your longest time!</p>\n\n</ion-content>\n\n<div id=\"btn-wrapper\">\n  <ion-button color=\"danger\" id=\"danger-btn\" (click)=\"discardTime()\">NOPE</ion-button>\n  <ion-button color=\"primary\" id=\"primary-btn\" (click)=\"acceptTime()\">OKAY</ion-button>\n</div>\n");

/***/ }),

/***/ "./src/app/home/stop/stop-routing.module.ts":
/*!**************************************************!*\
  !*** ./src/app/home/stop/stop-routing.module.ts ***!
  \**************************************************/
/*! exports provided: StopPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StopPageRoutingModule", function() { return StopPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _stop_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stop.page */ "./src/app/home/stop/stop.page.ts");




const routes = [
    {
        path: '',
        component: _stop_page__WEBPACK_IMPORTED_MODULE_3__["StopPage"]
    }
];
let StopPageRoutingModule = class StopPageRoutingModule {
};
StopPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], StopPageRoutingModule);



/***/ }),

/***/ "./src/app/home/stop/stop.module.ts":
/*!******************************************!*\
  !*** ./src/app/home/stop/stop.module.ts ***!
  \******************************************/
/*! exports provided: StopPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StopPageModule", function() { return StopPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _stop_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./stop-routing.module */ "./src/app/home/stop/stop-routing.module.ts");
/* harmony import */ var _stop_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./stop.page */ "./src/app/home/stop/stop.page.ts");







let StopPageModule = class StopPageModule {
};
StopPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _stop_routing_module__WEBPACK_IMPORTED_MODULE_5__["StopPageRoutingModule"]
        ],
        declarations: [_stop_page__WEBPACK_IMPORTED_MODULE_6__["StopPage"]]
    })
], StopPageModule);



/***/ }),

/***/ "./src/app/home/stop/stop.page.scss":
/*!******************************************!*\
  !*** ./src/app/home/stop/stop.page.scss ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("p {\n  color: var(--ion-color-secondary);\n  font-size: 48px;\n  line-height: 48px;\n  margin: 32px 24px;\n}\np span {\n  color: var(--ion-color-dark);\n}\n#para-one {\n  margin: 40px 24px 32px 24px;\n}\n#para-two {\n  text-align: right;\n}\n#btn-wrapper {\n  width: 100vw;\n  display: flex;\n  justify-content: space-evenly;\n  align-items: center;\n  margin-bottom: 16px;\n  background: var(--ion-color-background);\n}\n#btn-wrapper ion-button {\n  max-width: 45vw;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9zdG9wL3N0b3AucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUNBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQUNGO0FBQ0U7RUFDRSw0QkFBQTtBQUNKO0FBSUE7RUFDRSwyQkFBQTtBQURGO0FBSUE7RUFDRSxpQkFBQTtBQURGO0FBSUE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLHVDQUFBO0FBREY7QUFHRTtFQUNFLGVBQUE7QUFESiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvc3RvcC9zdG9wLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbInAge1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kYXJ5KTtcclxuICBmb250LXNpemU6IDQ4cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDQ4cHg7XHJcbiAgbWFyZ2luOiAzMnB4IDI0cHg7XHJcblxyXG4gICYgc3BhbiB7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gIH1cclxufVxyXG5cclxuXHJcbiNwYXJhLW9uZSB7XHJcbiAgbWFyZ2luOiA0MHB4IDI0cHggMzJweCAyNHB4O1xyXG59XHJcblxyXG4jcGFyYS10d28ge1xyXG4gIHRleHQtYWxpZ246IHJpZ2h0O1xyXG59XHJcblxyXG4jYnRuLXdyYXBwZXIge1xyXG4gIHdpZHRoOiAxMDB2dztcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmFja2dyb3VuZCk7XHJcblxyXG4gICYgaW9uLWJ1dHRvbiB7XHJcbiAgICBtYXgtd2lkdGg6IDQ1dnc7XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/home/stop/stop.page.ts":
/*!****************************************!*\
  !*** ./src/app/home/stop/stop.page.ts ***!
  \****************************************/
/*! exports provided: StopPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StopPage", function() { return StopPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_services_data_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/data-service.service */ "./src/app/services/data-service.service.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_app_services_item_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/item-storage.service */ "./src/app/services/item-storage.service.ts");
/* harmony import */ var src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/environment-storage.service */ "./src/app/services/environment-storage.service.ts");
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/toast.service */ "./src/app/services/toast.service.ts");









let StopPage = class StopPage {
    constructor(alertController, toastService, router, dataService, itemStorageService, environmentStorageService) {
        this.alertController = alertController;
        this.toastService = toastService;
        this.router = router;
        this.dataService = dataService;
        this.itemStorageService = itemStorageService;
        this.environmentStorageService = environmentStorageService;
        this.longestTime = null;
        this.shortestTime = null;
        this.firstTime = false;
    }
    get data() {
        return this.dataService.stopTime;
    }
    ngOnInit() {
        this.user = this.dataService.user;
        this.environment = this.dataService.environment;
        this.ifFirstTime();
        this.calcLongestPooTime(this.dataService.stopTimeRaw);
        this.calcShortestPooTime(this.dataService.stopTimeRaw);
        this.dataService.stopTime.length > 5 ? this.breakDownTimeInclHours(this.dataService.stopTime) : this.breakDownTime(this.dataService.stopTime);
        this.calculateMoney(this.dataService.stopTimeRaw, this.environment.hourlyRate);
    }
    ifFirstTime() {
        if (!this.environment.firstTimeDate) {
            this.firstTime = true;
        }
    }
    calculateMoney(time, hourlyRate) {
        if (time) {
            this.paidRaw = ((hourlyRate / 3600) * time);
            if (this.paidRaw < .01) {
                const paid = this.paidRaw.toFixed(3);
                this.formatMoney(paid);
            }
            else {
                const paid = this.paidRaw.toFixed(2);
                this.formatMoney(paid);
            }
        }
    }
    formatMoney(paid) {
        const currency = this.environment.currency;
        if (currency === '£ Pieces of Unicorn Dust' || currency === '$ Pieces of Eight' || currency === '£ Old Money Pounds') {
            const symbol = currency.slice(0, 1);
            const moneyType = currency.slice(2);
            this.paid = `${symbol}${paid} ${moneyType}`;
        }
        else {
            this.paid = `${currency}${paid}`;
        }
    }
    breakDownTime(wholeTime) {
        const minutes = wholeTime.slice(0, 2);
        const seconds = wholeTime.slice(3, 5);
        this.arrangeText(minutes);
        this.minutes = minutes.slice(0, 1) === '0' ? minutes.slice(1, 2) : minutes.slice(0, 2);
        this.seconds = seconds.slice(0, 1) === '0' ? seconds.slice(1, 2) : seconds.slice(0, 2);
    }
    breakDownTimeInclHours(wholeTime) {
        const hours = wholeTime.slice(0, 2);
        const minutes = wholeTime.slice(3, 5);
        const seconds = wholeTime.slice(6, 8);
        this.arrangeText(minutes, hours);
        this.hours = hours.slice(0, 1) === '0' ? hours.slice(1, 2) : hours.slice(0, 2);
        this.minutes = minutes.slice(0, 1) === '0' ? minutes.slice(1, 2) : minutes.slice(0, 2);
        this.seconds = seconds.slice(0, 1) === '0' ? seconds.slice(1, 2) : seconds.slice(0, 2);
    }
    arrangeText(minutes, hours) {
        if (!hours) {
            minutes === '00' ? this.showMinutes = false : this.showMinutes = true;
        }
        else {
            this.showMinutes = true;
            this.showHours = true;
        }
    }
    acceptTime() {
        const today = moment__WEBPACK_IMPORTED_MODULE_5__["now"]();
        const duration = this.dataService.stopTimeRaw;
        this.calcTotals(duration);
        this.calcStreak(today);
        if (this.firstTime) {
            this.environment.firstTimeDate = today;
        }
        if (this.longestTime !== null) {
            this.environment.longestTime = this.longestTime;
        }
        if (this.shortestTime !== null) {
            this.environment.shortestTime = this.shortestTime;
        }
        this.environment.lastTimeDate = today;
        this.environment.lastItemID += 1;
        this.environmentStorageService.updateEnvironment(this.environment);
        this.calcShortestPooTime(duration);
        this.calcTotalPaid();
        const createdAt = moment__WEBPACK_IMPORTED_MODULE_5__["now"]();
        const environmentID = this.user.activeEnvironmentID;
        const isLongest = this.longestTime ? true : false;
        const isShortest = this.shortestTime ? true : false;
        this.itemStorageService.addItem({
            id: this.environment.lastItemID,
            environmentID,
            duration,
            createdAt,
            worth: this.paidRaw,
            isLongest,
            isShortest
        }).then((poo) => {
            this.toastService.presentToast('Time Saved');
            this.router.navigate(['/home']);
        });
    }
    calcTotals(duration) {
        this.environment.totalTime += duration;
        this.environment.itemCount += 1;
        this.environment.totalPaid = this.environment.totalPaid += this.paidRaw;
    }
    calcStreak(date) {
        if (this.environment.lastTimeDate !== null) {
            const lastTimeDate = moment__WEBPACK_IMPORTED_MODULE_5__(this.environment.lastTimeDate).startOf('day');
            const today = moment__WEBPACK_IMPORTED_MODULE_5__(date).startOf('day');
            const diffTime = today.diff(lastTimeDate, 'days');
            if (diffTime > 0 && diffTime < 2) {
                this.environment.streak += 1;
            }
            else if (diffTime === 0) {
                this.environment.streak = this.environment.streak;
            }
            else {
                this.environment.streak = 1;
            }
        }
        else {
            this.environment.streak = 1;
        }
    }
    calcLongestPooTime(duration) {
        if (duration > this.environment.longestTime) {
            this.longestTime = duration;
        }
        if (this.environment.shortestTime === 0) {
            this.shortestTime = duration;
        }
    }
    calcShortestPooTime(duration) {
        if (duration < this.environment.shortestTime) {
            this.shortestTime = duration;
        }
    }
    calcTotalPaid() {
        if (this.environment.hourlyRate) {
            const time = this.environment.totalTime;
            this.environment.totalPaid = (this.environment.hourlyRate / 3600) * time;
        }
        else {
            this.environment.totalPaid = 0;
        }
    }
    discardTime() {
        this.presentAlertConfirm().then(ans => {
        });
    }
    presentAlertConfirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Confirm!',
                message: 'Do you want to discard this time?',
                cssClass: "alert-class",
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: "alert-cancel-button",
                        handler: (data) => {
                            console.log('Cancel');
                        }
                    }, {
                        text: 'Discard',
                        cssClass: "alert-confirm-button",
                        handler: () => {
                            this.dataService.stopTime = null;
                            this.dataService.stopTimeRaw = null;
                            this.toastService.presentToast('Time Discarded');
                            this.router.navigate(['/home']);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
StopPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_8__["ToastService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: src_app_services_data_service_service__WEBPACK_IMPORTED_MODULE_4__["DataServiceService"] },
    { type: src_app_services_item_storage_service__WEBPACK_IMPORTED_MODULE_6__["ItemStorageService"] },
    { type: src_app_services_environment_storage_service__WEBPACK_IMPORTED_MODULE_7__["EnvironmentStorageService"] }
];
StopPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-stop',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./stop.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/stop/stop.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./stop.page.scss */ "./src/app/home/stop/stop.page.scss")).default]
    })
], StopPage);



/***/ })

}]);
//# sourceMappingURL=stop-stop-module-es2015.js.map